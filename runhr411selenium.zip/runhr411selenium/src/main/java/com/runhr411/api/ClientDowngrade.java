package com.runhr411.api;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.utilities.ReadConfig;

public class ClientDowngrade  {

	public RestClient restClient;
	public ReadConfig rd;
	public HmacSha1Signature hm;
	public CloseableHttpResponse closeableHttpResponse;
	public BaseClass base;
	@SuppressWarnings("static-access")
	@Test
	public void ClientDowngradeAPITest() throws InvalidKeyException,
			SignatureException, NoSuchAlgorithmException, IOException {
		restClient = new RestClient();
		rd = new ReadConfig();
		base = new BaseClass();
		String hostName = rd.getapiHost();
		String downgradeURl = rd.getDowngradeAPIServiceURL();
		String authTime = base.getUTCCuttentTimestamp();

		String apiEndPoint = hostName + downgradeURl + authTime;
		System.out.println(apiEndPoint);

		String downgradeBody = "ooid=" + rd.getapiOOID() + "&bundle_id="
				+ rd.getapiBundleID();
		System.out.println(downgradeBody);
		String MD5 = hm.getMd5(downgradeBody);
		System.out.println(MD5);
		String stringToSign = apiEndPoint + "\n" + MD5;
		System.out.println(stringToSign);

		String authsignature = "195433:"
				+ hm.calculateRFC2104HMAC(stringToSign, "FY7r7umx9K");
		System.out.println(authsignature);
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/x-www-form-urlencoded");
		headerMap.put("X-Authorization", authsignature);

		closeableHttpResponse = restClient.post(apiEndPoint, downgradeBody,
				headerMap);

		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
		System.out.println(statusCode);
		Assert.assertEquals(statusCode, base.HTTP_RESPONSE_CODE_200);

		if (statusCode == base.HTTP_RESPONSE_CODE_200) {
			System.out.println("Client is downgraded successfully");
		} else if (statusCode == base.HTTP_RESPONSE_CODE_401) {
			System.out.println("Unauthorized");
		} else if (statusCode == base.HTTP_RESPONSE_CODE_500) {
			System.out.println("Server Error");
		}
		String responseString = EntityUtils.toString(
				closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responsejson = new JSONObject(responseString);
		System.out.println(responsejson);
	}
}

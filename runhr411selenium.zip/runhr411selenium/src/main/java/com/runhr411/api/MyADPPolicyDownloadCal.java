package com.runhr411.api;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.testng.annotations.Test;

import com.runhr411.utilities.ReadConfig;

public class MyADPPolicyDownloadCal {
	@Test
	public class MyAdpPolicyDownloadCalTest {

		public void getAAcalTest() throws ClientProtocolException, IOException {
			RestClient restClient = new RestClient();
			ReadConfig readConfig = new ReadConfig();
			String apiUri = readConfig.getPolicyDownloadCAl();
			HashMap<String, String> headerMap = new HashMap<String, String>();
			headerMap.put("orgoid", "G3EH7B2YHX17F52N");
			headerMap.put("associateoid", "G3EH7B2YHX175ZYT");
			restClient.get(apiUri, headerMap);

		}
	}
}

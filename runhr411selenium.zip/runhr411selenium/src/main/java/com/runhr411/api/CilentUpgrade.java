package com.runhr411.api;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.runhr411.pageobjects.BaseClass;
import com.runhr411.utilities.ReadConfig;

public class CilentUpgrade extends RestClient{

	
	public RestClient restClient;
	public ReadConfig rd;
	public HmacSha1Signature hm;
	public CloseableHttpResponse closeableHttpResponse;
	public BaseClass base;

	@SuppressWarnings("static-access")
	@Test
	public void ClientUpgradeAPITest() throws InvalidKeyException,
			SignatureException, NoSuchAlgorithmException, IOException {
		restClient = new RestClient();
		rd = new ReadConfig();
		base = new BaseClass();
		String hostName = rd.getapiHost();
		String upgradeURl = rd.getUpgradeAPIServiceURL();
		String authTime = base.getUTCCuttentTimestamp();

		String apiEndPoint = hostName + upgradeURl + authTime;
		logger1.info("API End Point is created");
		System.out.println(apiEndPoint);

		String upgradeBody = "ooid=" + rd.getapiOOID() + "&bundle_id="
				+ rd.getapiBundleID();
		logger1.info("API Client Upgrade Payload is built");
		System.out.println(upgradeBody);
		String MD5 = hm.getMd5(upgradeBody);
		logger1.info("MD5 Hashing is completed");
		System.out.println(MD5);
		String stringToSign = apiEndPoint + "\n" + MD5;
		logger1.info("MD5 is convetrted to String to Sign");
		System.out.println(stringToSign);
		String authsignature = "195433:"
				+ hm.calculateRFC2104HMAC(stringToSign, "FY7r7umx9K");
		logger1.info("Authsignature is generated with sha 512 algorithm");
		System.out.println(authsignature);
		logger1.info("Prepareing Headeres to be passed along with paylod");
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/x-www-form-urlencoded");
		headerMap.put("X-Authorization", authsignature);
		logger1.info("Headers are passed");

		closeableHttpResponse = restClient.post(apiEndPoint, upgradeBody,
				headerMap);
		logger1.info("Response Received");

		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
		System.out.println(statusCode);
		Assert.assertEquals(statusCode, base.HTTP_RESPONSE_CODE_200);
		if (statusCode == base.HTTP_RESPONSE_CODE_200) {
			System.out.println("Client is upgraded successfully");
		} else if (statusCode == base.HTTP_RESPONSE_CODE_401) {
			System.out.println("Unauthorized");
		} else if (statusCode == base.HTTP_RESPONSE_CODE_500) {
			System.out.println("Server Error");
		}
		String responseString = EntityUtils.toString(
				closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responsejson = new JSONObject(responseString);
		logger1.info("Json response is printing on console");
		System.out.println(responsejson);
	}
}
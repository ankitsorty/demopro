package com.runhr411.api;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.utilities.ReadConfig;

public class ClientProvision {

	public RestClient restClient;
	public ReadConfig rd;
	public HmacSha1Signature hm;
	public CloseableHttpResponse closeableHttpResponse;
	public BaseClass base;
	@SuppressWarnings("static-access")
	@Test
	public void ClientProvisioningAPITest() throws InvalidKeyException,
			SignatureException, NoSuchAlgorithmException, IOException {
		restClient = new RestClient();
		rd = new ReadConfig();
		base = new BaseClass();
		String hostName = rd.getapiHost();
		String provisionURl = rd.getProvisionAPIServiceURL();
		String authTime = base.getUTCCuttentTimestamp();

		String apiEndPoint = hostName + provisionURl + authTime;
		System.out.println(apiEndPoint);
		String provisioningBody = "ooid="
                + rd.getapiOOID()
				+ "&partner_id=195433&client_id="
				+ rd.getapiIID()
				+ "&adp_code=HUG&company_name=R933onemoretest"
				+ rd.getapiIID()
				+ "&city=hugcity&state_code=NJ&region_code=KP&zip_code=08155&phone=(123)456-7890&fax=(123)456-7890&address2=hugaddress2"
				+ "&employee_count=5&contact_first_name=ankit&contact_last_name=sorty&address1=hugaddress&email=hug@hugtest.com"
				+ "&bundle_id="
				+ rd.getapiBundleID();
		System.out.println(provisioningBody);
		String MD5 = hm.getMd5(provisioningBody);
		System.out.println(MD5);
		String stringToSign = apiEndPoint + "\n" + MD5;
		System.out.println(stringToSign);

		String authsignature = "195433:"
				+ hm.calculateRFC2104HMAC(stringToSign, "FY7r7umx9K");
		System.out.println(authsignature);
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/x-www-form-urlencoded");
		headerMap.put("X-Authorization", authsignature);

		closeableHttpResponse = restClient.post(apiEndPoint, provisioningBody,
				headerMap);

		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
		System.out.println(statusCode);
		Assert.assertEquals(statusCode, base.HTTP_RESPONSE_CODE_200);
		System.out.println("Client is Provisioned successfully");
		if (statusCode == base.HTTP_RESPONSE_CODE_200) {
			System.out.println("Client is Provisioned successfully");
		} else if (statusCode == base.HTTP_RESPONSE_CODE_401) {
			System.out.println("Unauthorized");
		} else if (statusCode == base.HTTP_RESPONSE_CODE_500) {
			System.out.println("Server Error");
		}
		String responseString = EntityUtils.toString(
				closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responsejson = new JSONObject(responseString);
		System.out.println(responsejson);
	}

}

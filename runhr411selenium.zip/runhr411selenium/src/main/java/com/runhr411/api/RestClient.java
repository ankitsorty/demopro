package com.runhr411.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;

import com.runhr411.pageobjects.BaseClass;

public class RestClient {

	public BaseClass base;
	public Logger logger1;

	@SuppressWarnings("deprecation")
	@BeforeMethod
	public void setup() throws Exception {

		logger1 = Logger.getLogger("runhr411automation");
		PropertyConfigurator.configure("log4j.properties");
		freemarker.log.Logger
		.selectLoggerLibrary(freemarker.log.Logger.LIBRARY_NONE);
		logger1.info("*********Welcome to API Automation World***********");
	}

	public CloseableHttpResponse post(String url, String entityString,
			HashMap<String, String> headerMap) throws IOException {

		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httppost = new HttpPost(url);
		httppost.setEntity(new StringEntity(entityString));
		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httppost.addHeader(entry.getKey(), entry.getValue());
		}

		CloseableHttpResponse closablehttpresponse = httpclient
				.execute(httppost);
		return closablehttpresponse;

	}

	public void get(String url, HashMap<String, String> headerMap)
			throws ClientProtocolException, IOException {
		base = new BaseClass();
		CloseableHttpClient httpclient1 = HttpClients.createDefault();
		HttpGet httpget = new HttpGet(url);
		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httpget.addHeader(entry.getKey(), entry.getValue());
		}
		CloseableHttpResponse closablehttpresponse1 = httpclient1
				.execute(httpget);
		int statusCode = closablehttpresponse1.getStatusLine().getStatusCode();
		System.out.println("Status Code = " + statusCode);
		// Assert.assertEquals(statusCode, base.HTTP_RESPONSE_CODE_200);
		String responseString = EntityUtils.toString(
				closablehttpresponse1.getEntity(), "UTF-8");
		System.out.println(responseString);
		JSONObject responseJson = new JSONObject(
				responseString.substring(responseString.indexOf('{')));
		System.out.println("Response Json from API " + responseJson);
		Header[] headerArray = closablehttpresponse1.getAllHeaders();
		HashMap<String, String> allHeaders = new HashMap<String, String>();
		for (Header header : headerArray) {
			allHeaders.put(header.getName(), header.getValue());
		}
		System.out.println("Headers Present are " + allHeaders);
	}
}

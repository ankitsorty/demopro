package com.runhr411.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.AdminPanel;
import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class AccountResnstatementTest extends BaseClass {
	HomePage homepage = new HomePage(driver);
	ReadConfig readconfig = new ReadConfig();

	@Test(priority = 0)
	public void accountReinstateTest() throws InterruptedException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		accReinstatementdetails();
		WebElement element = driver.findElement(By
				.xpath("//*[@id='adminButton-button']/div[2]/li/a"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);
		AdminPanel adminPanel = new AdminPanel(driver);
		adminPanel.testAdminIID("77391963");
		adminPanel.clickOnGetUser();
		adminPanel.clickOnGetUserRecord();
		Thread.sleep(2000);
		switchTab(driver);
		checkElementsPresent();

	}
	@Test(priority = 1)
	public void archiveAccountTest() throws InterruptedException{
		accountReinstateTest();
	}

	public void checkElementsPresent() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		if (driver.getPageSource().contains("Archive Account")) {
			js.executeScript("arguments[0].click();", driver.findElement(By
					.xpath("//div[contains(text(), 'Archive Account')]")));
			driver.switchTo().alert().accept();
			driver.switchTo().defaultContent();
			Thread.sleep(2000);
			if (driver.getPageSource().contains(
					"You have successfully archived user")) {
				Assert.assertTrue(true);
				logger.info("Account is Archived");
			} else {
				Assert.assertTrue(false);
				logger.info("Something Went Wrong, Unable to Archive Account");
			}
		} else {

			if (driver.getPageSource().contains("Reinstate Account")) {
				js.executeScript("arguments[0].click();", driver.findElement(By
						.xpath("//div[contains(text(), 'Reinstate Account')]")));
				driver.switchTo().alert().accept();
				driver.switchTo().defaultContent();
				Thread.sleep(2000);
				if (driver.getPageSource().contains(
						"You have successfully reinstated user")) {
					Assert.assertTrue(true);
					logger.info("Account is Rinstated");
				} else {
					Assert.assertTrue(false);
					logger.info("Something Went Wrong, Unable to reinstate Account");
				}
			}

		}

	}

}

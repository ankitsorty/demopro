package com.runhr411.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class HR411_Essential_Navigations extends BaseClass {

	ReadConfig readconfig = new ReadConfig();

	@Test(priority = 0, groups = { "GeneralNavigations" })
	public void verifyMyHRProfileLinkForHR411EssentialBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnMyHrProfileLink();
		if (driver.getPageSource().contains("My HR Profile")) {
			Assert.assertTrue(true);
			logger.info("My HR Profile Page is displayed");
		} else {
			captureScreenshot(driver, "verifyMyHRProfileLink");
			logger.info("My HR Profile-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 1, groups = { "GeneralNavigations" })
	public void verifySupportCenterLinkForHR411EssentialBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnSupportCentreLink();
		if (driver.getPageSource().contains("HR411 Product Support")) {
			Assert.assertTrue(true);
			logger.info("Support Centre Page is displayed");
		} else {
			captureScreenshot(driver, "verifySupportCentreLink");
			logger.info("Support Centre Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 2, groups = { "GeneralNavigations" })
	public void verifyLogoutLinkForHR411EssentialBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnLogoutLink();
		if (driver.getPageSource().contains("HR411")) {
			Assert.assertTrue(true);
			logger.info("Client is logged out Successfully");
		} else {
			captureScreenshot(driver, "verifyLogoutLink");
			logger.info("Logout Failed-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 3, groups = { "GeneralNavigations" })
	public void verifyHomePageLinkForHR411EssentialBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnHomePage();
		if (driver.getTitle().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Home Page is displayed");
		} else {
			captureScreenshot(driver, "verifyHomePageNavigationLink");
			logger.info("Home Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 4, groups = { "GeneralNavigations" })
	public void verifyComlpiancestateandfederalLinkForHR411EssentialBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnComplianceStateFederalLink(driver);
		if (driver.getPageSource().contains("State & Federal Resources")) {
			Assert.assertTrue(true);
			logger.info("State & Federal Resources Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceFederalResourcesLink");
			logger.info("State & Federal Resources Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 5, groups = { "GeneralNavigations" })
	public void verifyComlpianceHRCheckupsLinkForHR411EssentialBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnComplianceHRCheckupsLink(driver);
		if (driver.getPageSource().contains("HR Checkups")) {
			Assert.assertTrue(true);
			logger.info("HR Check-ups Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyHRCheckupsLink");
			logger.info("HR Check-ups Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 6, groups = { "GeneralNavigations" })
	public void verifyLIBWebcastLinkHR411EssentialBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.hoverMouseOverLibrary(driver);
		Thread.sleep(3000);
		switchTab(driver);
		if (driver.getTitle().contains(readconfig.libHRproductWebcastLink())) {
			Assert.assertTrue(true);
			logger.info("HR Webinar Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibHRWebcastLink");
			logger.info("HR Webinar Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 7, groups = { "GeneralNavigations" })
	public void verifyLIBNewHirePaperWorkLinkHR411EssentialBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnLibraryNewHirePaperWorkLink(driver);
		if (driver.getPageSource().contains("New Hire Paperwork")) {
			Assert.assertTrue(true);
			logger.info("New Hire Paperwork Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryNewHirePaperWorkLink");
			logger.info("New Hire Paperwork Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 8, groups = { "GeneralNavigations" })
	public void verifyLIBTipOfWeekLinkHR411EssentialBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnLibraryTipOfTheWeekLink(driver);
		if (driver.getPageSource().contains("HR Tip of the Week")) {
			Assert.assertTrue(true);
			logger.info("HR Tip of the Week Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryTipOfTheWeekLink");
			logger.info("HR Tip of the Week Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 9, groups = { "GeneralNavigations" })
	public void verifyLIBHRNewsLetterLinkHR411EssentialBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnLibraryHRNewsLetterLink(driver);
		if (driver.getPageSource().contains("HR Newsletter")) {
			Assert.assertTrue(true);
			logger.info("HR Newsletter Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRNewsLetterLink");
			logger.info("HR Newsletter Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 10, groups = { "GeneralNavigations" })
	public void verifyLIBHRDictionaryLinkHR411EssentialBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEssentialDetails();
		homepage.clickOnLibraryHRDictionaryLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("HR Dictionary")) {
			Assert.assertTrue(true);
			logger.info("HR Dictionary Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRDictionaryLink");
			logger.info("HR Dictionary Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

}

package com.runhr411.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class HR411_Enhanced_Navigation extends BaseClass {

	ReadConfig readconfig = new ReadConfig();

	@Test(priority = 0)
	public void verifyMyHRProfileLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnMyHrProfileLink();
		if (driver.getPageSource().contains("My HR Profile")) {
			Assert.assertTrue(true);
			logger.info("My HR Profile Page is displayed");
		} else {
			captureScreenshot(driver, "verifyMyHRProfileLink");
			logger.info("My HR Profile-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 1)
	public void verifySupportCenterLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnSupportCentreLink();
		if (driver.getPageSource().contains("HR411 Product Support")) {
			Assert.assertTrue(true);
			logger.info("Support Centre Page is displayed");
		} else {
			captureScreenshot(driver, "verifySupportCentreLink");
			logger.info("Support Centre Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 2)
	public void verifyLogoutLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnLogoutLink();
		if (driver.getPageSource().contains("HR411")) {
			Assert.assertTrue(true);
			logger.info("Client is logged out Successfully");
		} else {
			captureScreenshot(driver, "verifyLogoutLink");
			logger.info("Logout Failed-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 3)
	public void verifyHRHelpdeskLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnHrHeplDeskLink();
		if (driver.getPageSource().contains(
				"for your day-to-day employee management questions regarding")) {
			Assert.assertTrue(true);
			logger.info("HR HelpDesk Page is displayed");
		} else {
			captureScreenshot(driver, "verifyHRHelpdeskLink");
			logger.info("HR HelpDesk Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 4)
	public void verifyHomePageLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnHomePage();
		if (driver.getTitle().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Home Page is displayed");
		} else {
			captureScreenshot(driver, "verifyHomePageNavigationLink");
			logger.info("Home Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 5)
	public void verifyComlpiancestateandfederalLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnComplianceStateFederalLink(driver);
		if (driver.getPageSource().contains("State & Federal Resources")) {
			Assert.assertTrue(true);
			logger.info("State & Federal Resources Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceFederalResourcesLink");
			logger.info("State & Federal Resources Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 6)
	public void verifyComlpianceDataBaseLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.hoverMouseOverCompliance(driver);
		homepage.ClickOnCmlceAlertCtnLink();
		switchTab(driver);
		Thread.sleep(4000);
		if (driver.getPageSource().contains(
				readconfig.ComplincedbExternalLink())) {
			Assert.assertTrue(true);
			logger.info("Litters Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceDbLink");
			logger.info("Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}

	@Test(priority = 7)
	public void verifyComlpianceUpdatesLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnComplianceUpdatesLink(driver);
		if (driver.getPageSource().contains("Compliance Updates")) {
			Assert.assertTrue(true);
			logger.info("Compliance Updates Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceUpdatesLink");
			logger.info("Compliance Updates Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}

	@Test(priority = 8)
	public void verifyComlpianceHRCheckupsLinkForHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnComplianceHRCheckupsLink(driver);
		if (driver.getPageSource().contains("HR Checkups")) {
			Assert.assertTrue(true);
			logger.info("HR Check-ups Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyHRCheckupsLink");
			logger.info("HR Check-ups Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}

	}

	@Test(priority = 9)
	public void verifyLIBWebcastLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.hoverMouseOverLibrary(driver);
		Thread.sleep(3000);
		switchTab(driver);
		if (driver.getTitle().contains(readconfig.libHRproductWebcastLink())) {
			Assert.assertTrue(true);
			logger.info("HR Webinar Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibHRWebcastLink");
			logger.info("HR Webinar Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 10)
	public void verifyLIBNewHirePaperWorkLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnLibraryNewHirePaperWorkLink(driver);
		if (driver.getPageSource().contains("New Hire Paperwork")) {
			Assert.assertTrue(true);
			logger.info("New Hire Paperwork Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryNewHirePaperWorkLink");
			logger.info("New Hire Paperwork Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 11)
	public void verifyLIBTipOfWeekLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnLibraryTipOfTheWeekLink(driver);
		if (driver.getPageSource().contains("HR Tip of the Week")) {
			Assert.assertTrue(true);
			logger.info("HR Tip of the Week Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryTipOfTheWeekLink");
			logger.info("HR Tip of the Week Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 12)
	public void verifyLIBHRNewsLetterLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnLibraryHRNewsLetterLink(driver);
		if (driver.getPageSource().contains("HR Newsletter")) {
			Assert.assertTrue(true);
			logger.info("HR Newsletter Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRNewsLetterLink");
			logger.info("HR Newsletter Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 13)
	public void verifyLIBHRDictionaryLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnLibraryHRDictionaryLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("HR Dictionary")) {
			Assert.assertTrue(true);
			logger.info("HR Dictionary Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRDictionaryLink");
			logger.info("HR Dictionary Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 14)
	public void verifyToolkitHiringLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitHiringLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Hiring")) {
			Assert.assertTrue(true);
			logger.info("Hiring Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitHiringLink");
			logger.info("Hiring Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 15)
	public void verifyToolkitJDLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitJDLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Job Descriptions")) {
			Assert.assertTrue(true);
			logger.info("Job Descriptions Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitJDLink");
			logger.info("Job Descriptions Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 16)
	public void verifyToolkitInterviewingLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitInterviewingLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Interviewing")) {
			Assert.assertTrue(true);
			logger.info("Interviewing Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitInterviewingLink");
			logger.info("Interviewing Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 17)
	public void verifyToolkitBGScreeningLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitBCScreeningLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Background Screening")) {
			Assert.assertTrue(true);
			logger.info("Background Screening Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitBCScreeningLink");
			logger.info("Background Screening Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 18)
	public void verifyToolkitNewEmpOreintationLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitNewEmpOreintationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("New Employee Orientation")) {
			Assert.assertTrue(true);
			logger.info("New Employee Orientation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitNewEmpOreintationLink");
			logger.info("New Employee Orientation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 19)
	public void verifyToolkitBenefitsLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitBenefitsLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Benefits")) {
			Assert.assertTrue(true);
			logger.info("Benefits Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitBenefitsLink");
			logger.info("Benefits Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 20)
	public void verifyToolkitCompensationLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitCompensationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Compensation")) {
			Assert.assertTrue(true);
			logger.info("Compensation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitCompensationLink");
			logger.info("Compensation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 21)
	public void verifyToolkitACALinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitACALink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Affordable Care Act")) {
			Assert.assertTrue(true);
			logger.info("Affordable Care Act (ACA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitACALink");
			logger.info("Affordable Care Act (ACA) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 22)
	public void verifyToolkitDisciplineLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitDisciplineLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Discipline")) {
			Assert.assertTrue(true);
			logger.info("Discipline Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitDisciplineLink");
			logger.info("Discipline Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 23)
	public void verifyToolkitTerminationLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitTerminationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Termination")) {
			Assert.assertTrue(true);
			logger.info("Termination Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitTerminationLink");
			logger.info("Termination Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 24)
	public void verifyToolkitPerfomrmanceMgmtLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitPerformanceMgmtLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Performance Management")) {
			Assert.assertTrue(true);
			logger.info("Performance Management Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitPerformanceMgmtLink");
			logger.info("Performance Management Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 25)
	public void verifyToolkitSexulaHarrassmentLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitSexualHarassmentLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Sexual Harassment Prevention")) {
			Assert.assertTrue(true);
			logger.info("Sexual Harassment Prevention Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitSexualHarassmentLink");
			logger.info("Sexual Harassment Prevention Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 26)
	public void verifyToolkitHBandPoliciesLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitHBAndPoliciesLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Handbooks")) {
			Assert.assertTrue(true);
			logger.info("Handbooks and Policies Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitHBAndPoliciesLink");
			logger.info("Handbooks and Policies Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 27)
	public void verifyToolkitRecordKeepingLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitRecordKeepingLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Recordkeeping")) {
			Assert.assertTrue(true);
			logger.info("Recordkeeping Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitRecordKeepingLink");
			logger.info("Recordkeeping Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 28)
	public void verifyToolkitFMLALinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitFLMALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Family and Medical Leave Act")) {
			Assert.assertTrue(true);
			logger.info("Family and Medical Leave Act (FMLA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitFLMALink");
			logger.info("Family and Medical Leave Act (FMLA) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 29)
	public void verifyToolkitImmigrationNEverifyLinkHR411EnhancedBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageEnhancedDetails();
		homepage.clickOnToolkitImigrationAndEVerifyLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Immigration")) {
			Assert.assertTrue(true);
			logger.info("Immigration and E-Verify Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitImigrationAndEVerifyLink");
			logger.info("Immigration and E-Verify Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}
}

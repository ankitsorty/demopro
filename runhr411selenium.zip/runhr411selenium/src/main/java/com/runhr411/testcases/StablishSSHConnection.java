package com.runhr411.testcases;

import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.Test;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.runhr411.utilities.ReadConfig;

public class StablishSSHConnection {

	/*
	  JSch Java SSH Connection Program
	 */
	@Test
	public static void csvImport() {
		ReadConfig readconfig = new ReadConfig();
		SFTP_FileUploader sftp = new SFTP_FileUploader();
		String host = readconfig.getTragethost();
		String user = readconfig.getTragethostuname();
		String password = readconfig.getTragethostpass();
		String command0 = "sudo su";
		String command1 = "ls HR411_*";
		String command2 = "rm HR411_*";
		String command3 = "scp HR411_* /home/wholesalesftp/runprovisioningfiles/";
		String command4 = "/app/apache2/php/bin/php /var/www/vhosts/www.hr411.com/_accountManagement/init.php -mnow";
		try {

			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			Session session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");
			Channel channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command0);
			((ChannelExec) channel).setCommand(command2);
			sftp.fileUpload(readconfig.getLocalFilePath1());
			sftp.fileUpload(readconfig.getLocalFilePath2());
			sftp.fileUpload(readconfig.getLocalFilePath3());
			((ChannelExec) channel).setCommand(command1);
			((ChannelExec) channel).setCommand(command3);
			((ChannelExec) channel).setCommand(command4);
			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);
			InputStream in = channel.getInputStream();
			channel.connect();
			byte[] tmp = new byte[4096];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 4096);
					if (i < 0)
						break;
					System.out.print(new String(tmp, 0, i));
				}
				if (channel.isClosed()) {
					System.out.println("exit-status: "
							+ channel.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {
				}
			}
			channel.disconnect();
			session.disconnect();
			System.out.println("DONE");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

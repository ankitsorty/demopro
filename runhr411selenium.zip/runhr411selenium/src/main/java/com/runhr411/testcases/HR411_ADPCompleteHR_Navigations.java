package com.runhr411.testcases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;

public class HR411_ADPCompleteHR_Navigations extends BaseClass {
	
	BCCheckGeneralNavigations_TC_003 bc;
	EmpHandbookNavigation_TC_008 emp;
	JDGeneralNavigations_TC_008 jd;
	
	@Test(priority = 0, groups = { "GeneralNavigations" })
	public void verifyMyHRProfileLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HeaderNavigations_TC_010 hd = new HeaderNavigations_TC_010();
		hd.verifyMyHRProfileLink();
	}

	@Test(priority = 1, groups = { "GeneralNavigations" })
	public void verifySupportCenterLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HeaderNavigations_TC_010 hd = new HeaderNavigations_TC_010();
		hd.verifySupportCentreLink();
	}

	@Test(priority = 2, groups = { "GeneralNavigations" })
	public void verifyLogoutLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HeaderNavigations_TC_010 hd = new HeaderNavigations_TC_010();
		hd.verifyLogoutLink();
	}

	@Test(priority = 3, groups = { "GeneralNavigations" })
	public void verifyHRHelpdeskLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HeaderNavigations_TC_010 hd = new HeaderNavigations_TC_010();
		hd.verifyHRHelpdeskLink();
	}

	@Test(priority = 4, groups = { "GeneralNavigations" })
	public void verifyHomePageLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HomePageLinkNavigation_TC_009 hp = new HomePageLinkNavigation_TC_009();
		hp.verifyHomePageNavigationLink();
	}
	
	@Test(priority = 5, groups = { "GeneralNavigations" })
	public void verifyBCLinkHR411ADPCompeteHRBundle() throws InterruptedException,
			IOException {
		bc = new BCCheckGeneralNavigations_TC_003();
		bc.verifyBCLink();
	}
	
	@Test(priority = 6, groups = { "GeneralNavigations" })
	public void verifyBCScreeningLinkHR411ADPCompeteHRBundle() throws InterruptedException,
			IOException {
		bc = new BCCheckGeneralNavigations_TC_003();
		bc.verifyBCscreeningLink();
	}
	
	@Test(priority = 7, groups = { "GeneralNavigations" })
	public void verifyEMPHandbookLinkHR411ADPCompeteHRBundle() throws InterruptedException,
			IOException {
		emp = new EmpHandbookNavigation_TC_008();
		emp.verifyEmpHandbookNavigationLink();
	}

	@Test(priority = 8, groups = { "GeneralNavigations" })
	public void verifyComlpiancestateandfederalLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ComplianceGeneralNavigations_TC_004 cp = new ComplianceGeneralNavigations_TC_004();
		cp.VerifyComplianceFederalResourcesLink();
	}

	@Test(priority = 9, groups = { "GeneralNavigations" })
	public void verifyComlpianceDataBaseLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ComplianceGeneralNavigations_TC_004 cp = new ComplianceGeneralNavigations_TC_004();
		cp.VerifyComplianceDbLink();
	}

	@Test(priority = 10, groups = { "GeneralNavigations" })
	public void verifyComlpianceUpdatesLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ComplianceGeneralNavigations_TC_004 cp = new ComplianceGeneralNavigations_TC_004();
		cp.VerifyComplianceUpdatesLink();
	}

	@Test(priority = 11, groups = { "GeneralNavigations" })
	public void verifyComlpianceHRCheckupsLinkForHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ComplianceGeneralNavigations_TC_004 cp = new ComplianceGeneralNavigations_TC_004();
		cp.VerifyHRCheckupsLink();
	}
	
	/*@Test(priority = 12, groups = { "GeneralNavigations" })
	public void verifyLIBHRTrainingLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HR_LibraryGeneralNavigations_TC005 lib = new HR_LibraryGeneralNavigations_TC005();
		lib.VerifyLibraryHRTrainingLink();
	}*/
	
	@Test(priority = 13, groups = { "GeneralNavigations" })
	public void verifyLIBFormsandDocsLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HR_LibraryGeneralNavigations_TC005 lib = new HR_LibraryGeneralNavigations_TC005();
		lib.VerifyLibraryFormsAndDocsLink();
	}

	@Test(priority = 14, groups = { "GeneralNavigations" })
	public void verifyLIBWebcastLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HR_LibraryGeneralNavigations_TC005 lib = new HR_LibraryGeneralNavigations_TC005();
		lib.VerifyLibHRWebcastLink();
	}

	@Test(priority = 15, groups = { "GeneralNavigations" })
	public void verifyLIBNewHirePaperWorkLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HR_LibraryGeneralNavigations_TC005 lib = new HR_LibraryGeneralNavigations_TC005();
		lib.VerifyLibraryNewHirePaperWorkLink();
	}

	@Test(priority = 16, groups = { "GeneralNavigations" })
	public void verifyLIBTipOfWeekLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HR_LibraryGeneralNavigations_TC005 lib = new HR_LibraryGeneralNavigations_TC005();
		lib.VerifyLibraryTipOfTheWeekLink();
	}

	@Test(priority = 17, groups = { "GeneralNavigations" })
	public void verifyLIBHRNewsLetterLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HR_LibraryGeneralNavigations_TC005 lib = new HR_LibraryGeneralNavigations_TC005();
		lib.VerifyLibraryHRNewsLetterLink();
	}

	@Test(priority = 18, groups = { "GeneralNavigations" })
	public void verifyLIBHRDictionaryLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		HR_LibraryGeneralNavigations_TC005 lib = new HR_LibraryGeneralNavigations_TC005();
		lib.VerifyLibraryHRDictionaryLink();
	}

	@Test(priority = 19, groups = { "GeneralNavigations" })
	public void verifyToolkitHiringLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitHiringLink();
	}

	@Test(priority = 20, groups = { "GeneralNavigations" })
	public void verifyToolkitJDLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitJDLink();
	}

	@Test(priority = 21, groups = { "GeneralNavigations" })
	public void verifyToolkitInterviewingLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitInterviewingLink();
	}

	@Test(priority = 22, groups = { "GeneralNavigations" })
	public void verifyToolkitBGScreeningLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitBCScreeningLink();
	}

	@Test(priority = 23, groups = { "GeneralNavigations" })
	public void verifyToolkitNewEmpOreintationLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitNewEmpOreintationLink();
	}
	
	@Test(priority = 24, groups = { "GeneralNavigations" })
	public void verifyToolkitIndependantContractorsLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitIndependentContractorLink();
	}

	@Test(priority = 25, groups = { "GeneralNavigations" })
	public void verifyToolkitBenefitsLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitBenefitsLink();
	}

	@Test(priority = 26, groups = { "GeneralNavigations" })
	public void verifyToolkitCompensationLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitCompensationLink();
	}
	
	@Test(priority = 27, groups = { "GeneralNavigations" })
	public void verifyToolkitCOBRALinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitCOBRALink();
	}
	
	@Test(priority = 28, groups = { "GeneralNavigations" })
	public void verifyToolkitLeaveOfAbsenceLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitLeaveOfAbsenceLink();
	}
	
	@Test(priority = 29, groups = { "GeneralNavigations" })
	public void verifyToolkitWorkersCompensationLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitWorkersCompensationLink();
	}
	
	@Test(priority = 30, groups = { "GeneralNavigations" })
	public void verifyToolkitUnemploymentCompensationLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitUnemploymentCompensationLink();
	}

	@Test(priority = 31, groups = { "GeneralNavigations" })
	public void verifyToolkitACALinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitACALink();
	}

	@Test(priority = 32, groups = { "GeneralNavigations" })
	public void verifyToolkitDisciplineLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitDisciplineLink();
	}

	@Test(priority = 33, groups = { "GeneralNavigations" })
	public void verifyToolkitTerminationLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitTerminationLink();
	}

	@Test(priority = 34, groups = { "GeneralNavigations" })
	public void verifyToolkitPerfomrmanceMgmtLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitPerformanceMgmtLink();
	}

	@Test(priority = 35, groups = { "GeneralNavigations" })
	public void verifyToolkitSexulaHarrassmentLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitSexualHarassmentLink();
	}

	@Test(priority = 36, groups = { "GeneralNavigations" })
	public void verifyToolkitHBandPoliciesLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitHBAndPoliciesLink();
	}

	@Test(priority = 37, groups = { "GeneralNavigations" })
	public void verifyToolkitRecordKeepingLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitRecordKeepingLink();
	}

	@Test(priority = 38, groups = { "GeneralNavigations" })
	public void verifyToolkitFMLALinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitFLMALink();
	}
	
	@Test(priority = 39, groups = { "GeneralNavigations" })
	public void verifyToolkitEEOinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitEEOLink();
	}
	
	@Test(priority = 40, groups = { "GeneralNavigations" })
	public void verifyToolkitFederalContractorReqLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitFederalContractorReqLink();
	}
	
	@Test(priority = 41, groups = { "GeneralNavigations" })
	public void verifyToolkitADALinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitADALink();
	}
	
	@Test(priority = 42, groups = { "GeneralNavigations" })
	public void verifyToolkitFLSALinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitFLSALink();
	}
	
	@Test(priority = 43, groups = { "GeneralNavigations" })
	public void verifyToolkitOSHALinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitOSHALink();
	}

	@Test(priority = 44, groups = { "GeneralNavigations" })
	public void verifyToolkitImmigrationNEverifyLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		ToolkitGeneralNavigations_TC_007 toolkit = new ToolkitGeneralNavigations_TC_007();
		toolkit.verifyToolkitImigrationAndEVerifyLink();
	}
	
	@Test(priority = 45, groups = { "GeneralNavigations" })
	public void verifyMyJDLinkHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		jd = new JDGeneralNavigations_TC_008();
		jd.VerifyJDmMyJobDescriptionLink();
	}
	
	@Test(priority = 46, groups = { "GeneralNavigations" })
	public void verifyMyJDFindTemplateHR411ADPCompeteHRBundle()
			throws InterruptedException, IOException {
		jd = new JDGeneralNavigations_TC_008();
		jd.VerifyJDFindTemplateLink();
	}

}

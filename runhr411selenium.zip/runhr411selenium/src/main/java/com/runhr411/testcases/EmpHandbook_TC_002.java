package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HandbookGettingStartrdPage;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class EmpHandbook_TC_002 extends BaseClass {
	
	ReadConfig readconfig = new ReadConfig();
	
	@Test
	public void empHandbookGetStartedTest() throws InterruptedException, IOException{
		HomePage homepage = new HomePage(driver);
		HandbookGettingStartrdPage hbGettingStarted = new HandbookGettingStartrdPage(driver);
		commonHomePageDetails();
		homepage.clickOnMyEmpHBKIcon();
		logger.info("Clicked Employee Handbook Icon in shortcut menu");
		Thread.sleep(5000);
		boolean temp = driver.getPageSource().contains(readconfig.HBgetStartedbtn());
		Thread.sleep(3000);
		if (temp == true){
		hbGettingStarted.enterCompanyName(readconfig.getCompanyName());
		logger.info("Passing company Name");
		Thread.sleep(2000);
		hbGettingStarted.selectIndustryType();
		logger.info("Selecting Industry Type");
		Thread.sleep(2000);
		hbGettingStarted.enterNoOfEmployees(readconfig.getNoOfEmployees());
		logger.info("Passing Employee Count");
		Thread.sleep(2000);
		hbGettingStarted.clickOnGetStarted();
		logger.info("Clicked on Get Started Button");
		
		if (driver.getPageSource().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Clientt is on get Started Page");
		} else {
			captureScreenshot(driver, "empHandbookGetStartedTest");
			logger.info("Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
		}
	}
}

package com.runhr411.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class HR411_CompleteBundleNavigations extends BaseClass {

	ReadConfig readconfig = new ReadConfig();

	@Test(priority = 0, groups = { "GeneralNavigations" })
	public void verifyMyHRProfileLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnMyHrProfileLink();
		if (driver.getPageSource().contains("My HR Profile")) {
			Assert.assertTrue(true);
			logger.info("My HR Profile Page is displayed");
		} else {
			captureScreenshot(driver, "verifyMyHRProfileLink");
			logger.info("My HR Profile-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 1, groups = { "GeneralNavigations" })
	public void verifySupportCenterLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnSupportCentreLink();
		if (driver.getPageSource().contains("HR411 Product Support")) {
			Assert.assertTrue(true);
			logger.info("Support Centre Page is displayed");
		} else {
			captureScreenshot(driver, "verifySupportCentreLink");
			logger.info("Support Centre Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 2, groups = { "GeneralNavigations" })
	public void verifyLogoutLinkForHR411HR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnLogoutLink();
		if (driver.getPageSource().contains("HR411")) {
			Assert.assertTrue(true);
			logger.info("Client is logged out Successfully");
		} else {
			captureScreenshot(driver, "verifyLogoutLink");
			logger.info("Logout Failed-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 3, groups = { "GeneralNavigations" })
	public void verifyHRHelpdeskLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnHrHeplDeskLink();
		if (driver.getPageSource().contains(
				"for your day-to-day employee management questions regarding")) {
			Assert.assertTrue(true);
			logger.info("HR HelpDesk Page is displayed");
		} else {
			captureScreenshot(driver, "verifyHRHelpdeskLink");
			logger.info("HR HelpDesk Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 4, groups = { "GeneralNavigations" })
	public void verifyHomePageLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnHomePage();
		if (driver.getTitle().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Home Page is displayed");
		} else {
			captureScreenshot(driver, "verifyHomePageNavigationLink");
			logger.info("Home Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 7, groups = { "GeneralNavigations" })
	public void verifyEMPHandbookLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnEMPHandbookLink(driver);
		if (driver.getTitle().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Handbook Page is displayed");
		} else {
			captureScreenshot(driver, "verifyEmpHandbookNavigationLink");
			logger.info("Handbook Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 8, groups = { "GeneralNavigations" })
	public void verifyComlpiancestateandfederalLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnComplianceStateFederalLink(driver);
		if (driver.getPageSource().contains("State & Federal Resources")) {
			Assert.assertTrue(true);
			logger.info("State & Federal Resources Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceFederalResourcesLink");
			logger.info("State & Federal Resources Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 9, groups = { "GeneralNavigations" })
	public void verifyComlpianceDataBaseLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.hoverMouseOverCompliance(driver);
		homepage.ClickOnCmlceAlertCtnLink();
		switchTab(driver);
		Thread.sleep(4000);
		if (driver.getPageSource().contains(
				readconfig.ComplincedbExternalLink())) {
			Assert.assertTrue(true);
			logger.info("Litters Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceDbLink");
			logger.info("Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}

	@Test(priority = 10, groups = { "GeneralNavigations" })
	public void verifyComlpianceUpdatesLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnComplianceUpdatesLink(driver);
		if (driver.getPageSource().contains("Compliance Updates")) {
			Assert.assertTrue(true);
			logger.info("Compliance Updates Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceUpdatesLink");
			logger.info("Compliance Updates Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}

	@Test(priority = 11, groups = { "GeneralNavigations" })
	public void verifyComlpianceHRCheckupsLinkForHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnComplianceHRCheckupsLink(driver);
		if (driver.getPageSource().contains("HR Checkups")) {
			Assert.assertTrue(true);
			logger.info("HR Check-ups Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyHRCheckupsLink");
			logger.info("HR Check-ups Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 13, groups = { "GeneralNavigations" })
	public void verifyLIBFormsandDocsLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnLibraryFormsAndDocsLink(driver);
		Thread.sleep(1000);
		if (driver.getPageSource().contains("HR Forms")) {
			Assert.assertTrue(true);
			logger.info("HR Forms & Documents Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryFormsAndDocsLink");
			logger.info("HR Forms & Documents-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 14, groups = { "GeneralNavigations" })
	public void verifyLIBWebcastLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.hoverMouseOverLibrary(driver);
		Thread.sleep(3000);
		switchTab(driver);
		if (driver.getTitle().contains(readconfig.libHRproductWebcastLink())) {
			Assert.assertTrue(true);
			logger.info("HR Webinar Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibHRWebcastLink");
			logger.info("HR Webinar Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 15, groups = { "GeneralNavigations" })
	public void verifyLIBNewHirePaperWorkLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnLibraryNewHirePaperWorkLink(driver);
		if (driver.getPageSource().contains("New Hire Paperwork")) {
			Assert.assertTrue(true);
			logger.info("New Hire Paperwork Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryNewHirePaperWorkLink");
			logger.info("New Hire Paperwork Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 16, groups = { "GeneralNavigations" })
	public void verifyLIBTipOfWeekLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnLibraryTipOfTheWeekLink(driver);
		if (driver.getPageSource().contains("HR Tip of the Week")) {
			Assert.assertTrue(true);
			logger.info("HR Tip of the Week Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryTipOfTheWeekLink");
			logger.info("HR Tip of the Week Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 17, groups = { "GeneralNavigations" })
	public void verifyLIBHRNewsLetterLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnLibraryHRNewsLetterLink(driver);
		if (driver.getPageSource().contains("HR Newsletter")) {
			Assert.assertTrue(true);
			logger.info("HR Newsletter Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRNewsLetterLink");
			logger.info("HR Newsletter Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 18, groups = { "GeneralNavigations" })
	public void verifyLIBHRDictionaryLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnLibraryHRDictionaryLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("HR Dictionary")) {
			Assert.assertTrue(true);
			logger.info("HR Dictionary Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRDictionaryLink");
			logger.info("HR Dictionary Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 19, groups = { "GeneralNavigations" })
	public void verifyToolkitHiringLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitHiringLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Hiring")) {
			Assert.assertTrue(true);
			logger.info("Hiring Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitHiringLink");
			logger.info("Hiring Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 20, groups = { "GeneralNavigations" })
	public void verifyToolkitJDLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitJDLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Job Descriptions")) {
			Assert.assertTrue(true);
			logger.info("Job Descriptions Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitJDLink");
			logger.info("Job Descriptions Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 21, groups = { "GeneralNavigations" })
	public void verifyToolkitInterviewingLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitInterviewingLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Interviewing")) {
			Assert.assertTrue(true);
			logger.info("Interviewing Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitInterviewingLink");
			logger.info("Interviewing Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 22, groups = { "GeneralNavigations" })
	public void verifyToolkitBGScreeningLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitBCScreeningLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Background Screening")) {
			Assert.assertTrue(true);
			logger.info("Background Screening Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitBCScreeningLink");
			logger.info("Background Screening Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 23, groups = { "GeneralNavigations" })
	public void verifyToolkitNewEmpOreintationLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitNewEmpOreintationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("New Employee Orientation")) {
			Assert.assertTrue(true);
			logger.info("New Employee Orientation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitNewEmpOreintationLink");
			logger.info("New Employee Orientation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 24, groups = { "GeneralNavigations" })
	public void verifyToolkitIndependantContractorsLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitIndependantContractorLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Independent Contractors")) {
			Assert.assertTrue(true);
			logger.info("Independent Contractors Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitIndependentContractorLink");
			logger.info("Independent Contractors Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 25, groups = { "GeneralNavigations" })
	public void verifyToolkitBenefitsLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitBenefitsLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Benefits")) {
			Assert.assertTrue(true);
			logger.info("Benefits Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitBenefitsLink");
			logger.info("Benefits Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 26, groups = { "GeneralNavigations" })
	public void verifyToolkitCompensationLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitCompensationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Compensation")) {
			Assert.assertTrue(true);
			logger.info("Compensation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitCompensationLink");
			logger.info("Compensation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 27, groups = { "GeneralNavigations" })
	public void verifyToolkitCOBRALinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitCOBRALink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("COBRA")) {
			Assert.assertTrue(true);
			logger.info("COBRA Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitCOBRALink");
			logger.info("COBRA Page-->>Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 28, groups = { "GeneralNavigations" })
	public void verifyToolkitLeaveOfAbsenceLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitLeaveOfAbsenceLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Leave of Absence")) {
			Assert.assertTrue(true);
			logger.info("Leave of Absence Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitLeaveOfAbsenceLink");
			logger.info("Leave of Absence Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 29, groups = { "GeneralNavigations" })
	public void verifyToolkitWorkersCompensationLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitWorkersCompensationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Workers")) {
			Assert.assertTrue(true);
			logger.info("Worker's Compensation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitWorkersCompensationLink");
			logger.info("Worker's Compensation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 30, groups = { "GeneralNavigations" })
	public void verifyToolkitUnemploymentCompensationLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitUnemploymentCompensationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Unemployment Compensation")) {
			Assert.assertTrue(true);
			logger.info("Unemployment Compensation Page is displayed");
		} else {
			captureScreenshot(driver,
					"verifyToolkitUnemploymentCompensationLink");
			logger.info("Unemployment Compensation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 31, groups = { "GeneralNavigations" })
	public void verifyToolkitACALinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitACALink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Affordable Care Act")) {
			Assert.assertTrue(true);
			logger.info("Affordable Care Act (ACA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitACALink");
			logger.info("Affordable Care Act (ACA) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 32, groups = { "GeneralNavigations" })
	public void verifyToolkitDisciplineLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitDisciplineLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Discipline")) {
			Assert.assertTrue(true);
			logger.info("Discipline Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitDisciplineLink");
			logger.info("Discipline Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 33, groups = { "GeneralNavigations" })
	public void verifyToolkitTerminationLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitTerminationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Termination")) {
			Assert.assertTrue(true);
			logger.info("Termination Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitTerminationLink");
			logger.info("Termination Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 34, groups = { "GeneralNavigations" })
	public void verifyToolkitPerfomrmanceMgmtLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitPerformanceMgmtLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Performance Management")) {
			Assert.assertTrue(true);
			logger.info("Performance Management Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitPerformanceMgmtLink");
			logger.info("Performance Management Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 35, groups = { "GeneralNavigations" })
	public void verifyToolkitSexulaHarrassmentLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitSexualHarassmentLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Sexual Harassment Prevention")) {
			Assert.assertTrue(true);
			logger.info("Sexual Harassment Prevention Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitSexualHarassmentLink");
			logger.info("Sexual Harassment Prevention Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 36, groups = { "GeneralNavigations" })
	public void verifyToolkitHBandPoliciesLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitHBAndPoliciesLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Handbooks")) {
			Assert.assertTrue(true);
			logger.info("Handbooks and Policies Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitHBAndPoliciesLink");
			logger.info("Handbooks and Policies Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 37, groups = { "GeneralNavigations" })
	public void verifyToolkitRecordKeepingLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitRecordKeepingLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Recordkeeping")) {
			Assert.assertTrue(true);
			logger.info("Recordkeeping Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitRecordKeepingLink");
			logger.info("Recordkeeping Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 38, groups = { "GeneralNavigations" })
	public void verifyToolkitFMLALinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitFLMALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Family and Medical Leave Act")) {
			Assert.assertTrue(true);
			logger.info("Family and Medical Leave Act (FMLA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitFLMALink");
			logger.info("Family and Medical Leave Act (FMLA) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 39, groups = { "GeneralNavigations" })
	public void verifyToolkitEEOinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitEEOLink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Equal Employment Opportunity (EEO)")) {
			Assert.assertTrue(true);
			logger.info("Equal Employment Opportunity (EEO) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitEEOLink");
			logger.info("Equal Employment Opportunity (EEO) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 40, groups = { "GeneralNavigations" })
	public void verifyToolkitFederalContractorReqLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitFederalContractorReqLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Federal Contractor Requirements")) {
			Assert.assertTrue(true);
			logger.info("Federal Contractor Requirements Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitFederalContractorReqLink");
			logger.info("Federal Contractor Requirements Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 41, groups = { "GeneralNavigations" })
	public void verifyToolkitADALinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitADALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Americans with Disabilities Act (ADA)")) {
			Assert.assertTrue(true);
			logger.info("Americans with Disabilities Act (ADA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitADALink");
			logger.info("Americans with Disabilities Act (ADA)-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 42, groups = { "GeneralNavigations" })
	public void verifyToolkitFLSALinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitFLSALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Fair Labor Standards Act (FLSA)")) {
			Assert.assertTrue(true);
			logger.info("Fair Labor Standards Act (FLSA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitFLSALink");
			logger.info("Fair Labor Standards Act (FLSA)-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 43, groups = { "GeneralNavigations" })
	public void verifyToolkitOSHALinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitOSHALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains(
				"Occupational Safety and Health Act (OSH Act)")) {
			Assert.assertTrue(true);
			logger.info("Occupational Safety and Health Act (OSH Act) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitOSHALink");
			logger.info("Occupational Safety and Health Act (OSH Act) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 44, groups = { "GeneralNavigations" })
	public void verifyToolkitImmigrationNEverifyLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnToolkitImigrationAndEVerifyLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Immigration")) {
			Assert.assertTrue(true);
			logger.info("Immigration and E-Verify Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitImigrationAndEVerifyLink");
			logger.info("Immigration and E-Verify Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 45, groups = { "GeneralNavigations" })
	public void verifyMyJDLinkHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnMyJobDescriptionLink(driver);
		Thread.sleep(1000);
		if (driver.getPageSource().contains("My Job Descriptions")) {
			Assert.assertTrue(true);
			logger.info("My Job Descriptions Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyJDJobDescriptionLink");
			logger.info("My Job Descriptions Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 46, groups = { "GeneralNavigations" })
	public void verifyMyJDFindTemplateHR411_CompleteBundle()
			throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageHR411CompleteDetails();
		homepage.clickOnMyJobDescriptionFindTemplateLink(driver);
		Thread.sleep(1000);
		if (driver.getPageSource().contains("Browse By Job Type")) {
			Assert.assertTrue(true);
			logger.info("Find Tepmplate Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyJDFindTemplateLink");
			logger.info("Find Tepmplate Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}
}

package com.runhr411.testcases;

import java.io.File;
import java.io.FileInputStream;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.runhr411.utilities.ReadConfig;

public class SFTP_FileUploader {
	@SuppressWarnings("null")
	public void fileUpload(String fileName) {
		ReadConfig readconfig = new ReadConfig();
		String SFTPWORKINGDIR = readconfig.getTragethostDir();
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		System.out.println("preparing the host information for sftp.");
		try {
			channel = session.openChannel("sftp");
			channel.connect();
			System.out.println("sftp channel opened and connected.");
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(SFTPWORKINGDIR);
			File f = new File(fileName);
			boolean exists = f.exists();
			System.out.println(exists);
			channelSftp.put(new FileInputStream(f), f.getName());
		} catch (Exception ex) {
			System.out.println("Exception found while tranfer the response."
					+ ex);
		}
	}
}

package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class EmpHandbookNavigation_TC_008 extends BaseClass {
	
	ReadConfig readconfig = new ReadConfig();
	@Test
	public void verifyEmpHandbookNavigationLink() throws InterruptedException,
			IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnEMPHandbookLink(driver);
		if (driver.getTitle().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Handbook Page is displayed");
		} else {
			captureScreenshot(driver, "verifyEmpHandbookNavigationLink");
			logger.info("Handbook Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

}

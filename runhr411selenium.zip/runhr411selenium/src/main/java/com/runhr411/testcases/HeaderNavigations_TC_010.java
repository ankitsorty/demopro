package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class HeaderNavigations_TC_010 extends BaseClass {

	ReadConfig readconfig = new ReadConfig();

	@Test(priority = 0)
	public void verifyAdminPanelLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnAdminPanelLink1();
		if (driver.getTitle().contains(readconfig.getAdminPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Admin Panel Page is displayed");
		} else {
			captureScreenshot(driver, "verifyAdminPanelLink");
			logger.info("Admin Panel-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 1)
	public void verifyControlPanelLink() throws InterruptedException,
			IOException {
		HomePage homepage = new HomePage(driver);
		homepage.clickOnControlPanelLink();
		if (driver.getTitle().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Control Panel Page is displayed");
		} else {
			captureScreenshot(driver, "verifyControlPanelLink");
			logger.info("Control Panel-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 2)
	public void verifyMyHRProfileLink() throws InterruptedException,
			IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnMyHrProfileLink();
		if (driver.getPageSource().contains("My HR Profile")) {
			Assert.assertTrue(true);
			logger.info("My HR Profile Page is displayed");
		} else {
			captureScreenshot(driver, "verifyMyHRProfileLink");
			logger.info("My HR Profile-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 3)
	public void verifyHRHelpdeskLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnHrHeplDeskLink();
		if (driver.getPageSource().contains(
				"for your day-to-day employee management questions regarding")) {
			Assert.assertTrue(true);
			logger.info("HR HelpDesk Page is displayed");
		} else {
			captureScreenshot(driver, "verifyHRHelpdeskLink");
			logger.info("HR HelpDesk Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 4)
	public void verifySupportCentreLink() throws InterruptedException,
			IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnSupportCentreLink();
		if (driver.getPageSource().contains("HR411 Product Support")) {
			Assert.assertTrue(true);
			logger.info("Support Centre Page is displayed");
		} else {
			captureScreenshot(driver, "verifySupportCentreLink");
			logger.info("Support Centre Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 5)
	public void verifyLogoutLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnLogoutLink();
		if (driver.getPageSource().contains("HR411")) {
			Assert.assertTrue(true);
			logger.info("Client is logged out Successfully");
		} else {
			captureScreenshot(driver, "verifyLogoutLink");
			logger.info("Logout Failed-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

}

package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class BCCheckGeneralNavigations_TC_003 extends BaseClass {

	
	ReadConfig readconfig = new ReadConfig();

	@Test(priority = 0)
	public void verifyBCLink() throws IOException, InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnBGCLink(driver);
		Thread.sleep(2000);
		switchTab(driver);
		if (driver.getPageSource().contains(readconfig.BCLinkCheck())) {
			Assert.assertTrue(true);
			logger.info("ADP Select Page for BC check is displayed");
		} else {
			captureScreenshot(driver, "verifyBCLink");
			logger.info("ADP Select Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}

	@Test(priority = 1)
	public void verifyBCscreeningLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnBGCScreeningLink(driver);
		if (driver.getPageSource().contains("Background Screening")) {
			Assert.assertTrue(true);
			logger.info("Background Screening for BC check is displayed");
		} else {
			captureScreenshot(driver, "verifyBCscreeningLink");
			logger.info("Background Screening Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

}

package com.runhr411.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HBAckAccessCreateLoginPage;
import com.runhr411.pageobjects.HandbookMaintainacePage;
import com.runhr411.pageobjects.HbAccessCreateContactPage;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class SetEmpHBAccessMHO_TC_006 extends BaseClass {
	ReadConfig readconfig = new ReadConfig();

	@Test
	public void setEmployeeAccess() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		HBAckAccessCreateLoginPage hblp = new HBAckAccessCreateLoginPage(driver);
		HbAccessCreateContactPage hbAccess = new HbAccessCreateContactPage(
				driver);
		HandbookMaintainacePage hbmPage = new HandbookMaintainacePage(driver);
		commonHomePageDetails();
		homepage.clickOnMyEmpHBKIcon();
		Thread.sleep(2000);
		if (driver.getCurrentUrl().equals(readconfig.hbMaintainancePage())) {
			hbmPage.clickOnEmpAccessLogo();
			logger.info("Clicked on Emplyee Access Icon");
			hblp.getLoginURL(readconfig.getHBEmpAccessLoginUrl());
			logger.info("Entering Login URL");
			hblp.getCompanyIdentifier(readconfig.getHBEmpAccessCompanyID());
			logger.info("Entering Company Identifier");
			hblp.getPassword(readconfig.getHBAccessPassword());
			logger.info("Entering Password");
			((JavascriptExecutor) driver)
					.executeScript("window.scrollBy(0,500)");
			Thread.sleep(2000);
			hblp.clickOnNexttBtn();
			logger.info("Clicked on Next Button");
			Thread.sleep(2000);
			isAlertPresent();
			if (isAlertPresent() == true) {
				driver.switchTo().alert().accept();
				driver.switchTo().defaultContent();
				captureScreenshot(driver, "setEmployeeAccess");
				logger.info("Invalid inputs are given, Please provide valid inputs");
			} else {
				logger.info("Alert is not present, Continuing");
				WebElement element = driver.findElement(By
						.xpath("//a[contains(text(),'Next')]"));
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
				;
				logger.info("Clicking on next button on welcome page");
				Thread.sleep(2000);
				hbAccess.dismissQuickGuide();
				hbAccess.setEmpContactName(readconfig.getMHOAccEmpContactName());
				hbAccess.setEmpContactTitle(readconfig
						.getMHOAccEmpContactTitle());
				hbAccess.setEmpContactPhone(readconfig
						.getMHOAccEmpContactPhone());
				hbAccess.setEmpContactEmail(readconfig
						.getMHOAccEmpContactEmail());
				hbAccess.setEmpContactPhoneExt(readconfig
						.getMHOAccEmpContactphoneExt());
				hbAccess.setEmpContactAltPhoneExt(readconfig
						.getMHOAccEmpContactAltphoneExt());
				Thread.sleep(2000);
				WebElement element1 = driver
						.findElement(By
								.xpath("//a[@class = 'btnNextEmpAcc button button-primary']"));
				js.executeScript("arguments[0].click();", element1);
				logger.info("Clicking on next button");
				Thread.sleep(2000);
				String mhoUrl = driver.findElement(By.id("mySite")).getText();
				System.out.println(mhoUrl);
				Thread.sleep(2000);
				WebElement element2 = driver
						.findElement(By
								.xpath("//a[@class = 'btnDone button button-secondary']"));
				js.executeScript("arguments[0].click();", element2);
				logger.info("Clicking on Done button");
				Thread.sleep(2000);
				if (driver.getCurrentUrl().equals(
						readconfig.hbMaintainancePage())) {
					Assert.assertTrue(true);
					logger.info("Employee Access Successfully Created");
				} else {
					captureScreenshot(driver, "setEmployeeAccess");
					logger.info("Employee Access Setup is failed");
					Assert.assertTrue(false);
				}
			}
		}
	}
}

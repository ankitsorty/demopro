package com.runhr411.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.pageobjects.MyHRProfilePage;
import com.runhr411.utilities.ReadConfig;

public class MyHRProfileSaveDataTest extends BaseClass {

	ReadConfig readconfig = new ReadConfig();

	@Test
	public void myHRProfileSaveDataTest() throws InterruptedException, IOException {

		HomePage homepage = new HomePage(driver);
		MyHRProfilePage myHrProfilePage = new MyHRProfilePage(driver);
		commonHomePageDetails();
		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		homepage.clickOnMyHrProfileLink();
		Thread.sleep(2000);
		myHrProfilePage.clickOnContactInfoTab();
		myHrProfilePage.getContactFirstname("Ankit");
		myHrProfilePage.getContactLastname("Sorty");
		myHrProfilePage.getContactWorkEmail("Ankit.Sorty@ADP.com");
		myHrProfilePage.getContactWorkPhone("(999)999-9999");
		myHrProfilePage.getContactTitle("Mr");
		myHrProfilePage.getContactHRname("Prathibha Billa");
		myHrProfilePage.getContactHREmail("billap@adp.com");
		myHrProfilePage.getContactHRPhone("4233432455");
		myHrProfilePage.getContactHRTitle("Mrs");
		Thread.sleep(2000);
		myHrProfilePage.clickOnContactSaveButton();
		logger.info("Clicked on Save Button on Contacts Tab");
		getWait();
		myHrProfilePage.clickOnCompanyInfoTab();
		myHrProfilePage.getCompanyState(2);
		myHrProfilePage.getContactIndustry(3);
		myHrProfilePage.getContactAdditionalState(5);
		myHrProfilePage.clickOnCompanySaveButton();
		logger.info("Clicked on Save Button on Company Tab");
		getWait();
		myHrProfilePage.clickOnPracticeTab();
		myHrProfilePage.checkPracticeRadioButton();
		myHrProfilePage.clickOnPracticeSaveButton();
		logger.info("Clicked on Save Button on Practice Tab");
		getWait();
	}

	public void getWait() throws IOException {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		WebElement text = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By
						.xpath("//span[contains(text(), 'Successfully Saved')]")));
		String saveText = text.getText();
		if (saveText.equalsIgnoreCase("Successfully Saved")) {
			logger.info("Data Saved successfully");
			Assert.assertTrue(true);
		} else {
			logger.info("Exception occurred, unable to save data");
			captureScreenshot(driver, "setEmployeeAccess");
			Assert.assertTrue(false);
		}
	}
}

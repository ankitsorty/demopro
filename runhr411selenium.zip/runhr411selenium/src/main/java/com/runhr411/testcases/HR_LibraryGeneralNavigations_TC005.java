package com.runhr411.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class HR_LibraryGeneralNavigations_TC005 extends BaseClass {

	ReadConfig readconfig = new ReadConfig();
	

	@Test(priority = 0)
	public void VerifyLibraryFormsAndDocsLink() throws InterruptedException,
			IOException {
		driver.manage().timeouts().implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnLibraryFormsAndDocsLink(driver);
		Thread.sleep(1000);
		if (driver.getPageSource().contains("HR Forms")) {
			Assert.assertTrue(true);
			logger.info("HR Forms & Documents Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryFormsAndDocsLink");
			logger.info("HR Forms & Documents-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 1)
	public void VerifyLibHRWebcastLink() throws InterruptedException,
			IOException {
		driver.manage().timeouts().implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.hoverMouseOverLibrary(driver);
		Thread.sleep(3000);
		switchTab(driver);
		if (driver.getTitle().contains(readconfig.libHRproductWebcastLink())) {
			Assert.assertTrue(true);
			logger.info("HR Webinar Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibHRWebcastLink");
			logger.info("HR Webinar Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 2)
	public void VerifyLibraryNewHirePaperWorkLink()
			throws InterruptedException, IOException {
		driver.manage().timeouts().implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnLibraryNewHirePaperWorkLink(driver);
		if (driver.getPageSource().contains("New Hire Paperwork")) {
			Assert.assertTrue(true);
			logger.info("New Hire Paperwork Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryNewHirePaperWorkLink");
			logger.info("New Hire Paperwork Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 3)
	public void VerifyLibraryTipOfTheWeekLink() throws InterruptedException,
			IOException {
		driver.manage().timeouts().implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnLibraryTipOfTheWeekLink(driver);
		if (driver.getPageSource().contains("HR Tip of the Week")) {
			Assert.assertTrue(true);
			logger.info("HR Tip of the Week Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryTipOfTheWeekLink");
			logger.info("HR Tip of the Week Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 4)
	public void VerifyLibraryHRNewsLetterLink() throws InterruptedException,
			IOException {
		driver.manage().timeouts().implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnLibraryHRNewsLetterLink(driver);
		if (driver.getPageSource().contains("HR Newsletter")) {
			Assert.assertTrue(true);
			logger.info("HR Newsletter Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRNewsLetterLink");
			logger.info("HR Newsletter Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 5)
	public void VerifyLibraryHRDictionaryLink() throws InterruptedException,
			IOException {
		driver.manage().timeouts().implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnLibraryHRDictionaryLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("HR Dictionary")) {
			Assert.assertTrue(true);
			logger.info("HR Dictionary Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRDictionaryLink");
			logger.info("HR Dictionary Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 6)
	public void VerifyLibraryHRTrainingLink() throws InterruptedException,
			IOException {
		driver.manage().timeouts().implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnLibraryHRTrainingLink(driver);
		Thread.sleep(2000);
		homepage.ClickOnCmlceAlertCtnLink();
		switchTab(driver);
		Thread.sleep(5000);
		if (driver.getPageSource().contains("A Better Way to Learn")) {
			Assert.assertTrue(true);
			logger.info("Registration/Login Form Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyLibraryHRTrainingLink");
			logger.info("Registration/Login Form Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

}

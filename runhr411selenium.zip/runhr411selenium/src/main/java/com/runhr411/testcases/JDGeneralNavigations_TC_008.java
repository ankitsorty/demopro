package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;

public class JDGeneralNavigations_TC_008 extends BaseClass {
	
	@Test(priority = 0)
	public void VerifyJDmMyJobDescriptionLink() throws InterruptedException,
			IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnMyJobDescriptionLink(driver);
		Thread.sleep(1000);
		if (driver.getPageSource().contains("My Job Descriptions")) {
			Assert.assertTrue(true);
			logger.info("My Job Descriptions Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyJDJobDescriptionLink");
			logger.info("My Job Descriptions Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority = 1)
	public void VerifyJDFindTemplateLink() throws InterruptedException,
			IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnMyJobDescriptionFindTemplateLink(driver);
		Thread.sleep(1000);
		if (driver.getPageSource().contains("Browse By Job Type")) {
			Assert.assertTrue(true);
			logger.info("Find Tepmplate Page is displayed");
		} else {
			captureScreenshot(driver, "VerifyJDFindTemplateLink");
			logger.info("Find Tepmplate Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

}

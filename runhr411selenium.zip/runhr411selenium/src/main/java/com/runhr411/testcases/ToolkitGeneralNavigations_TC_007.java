package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;

public class ToolkitGeneralNavigations_TC_007 extends BaseClass {
	@Test(priority = 0)
	public void verifyToolkitHiringLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitHiringLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Hiring")) {
			Assert.assertTrue(true);
			logger.info("Hiring Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitHiringLink");
			logger.info("Hiring Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 1)
	public void verifyToolkitJDLink() throws IOException, InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitJDLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Job Descriptions")) {
			Assert.assertTrue(true);
			logger.info("Job Descriptions Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitJDLink");
			logger.info("Job Descriptions Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 2)
	public void verifyToolkitInterviewingLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitInterviewingLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Interviewing")) {
			Assert.assertTrue(true);
			logger.info("Interviewing Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitInterviewingLink");
			logger.info("Interviewing Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 3)
	public void verifyToolkitBCScreeningLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitBCScreeningLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Background Screening")) {
			Assert.assertTrue(true);
			logger.info("Background Screening Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitBCScreeningLink");
			logger.info("Background Screening Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 4)
	public void verifyToolkitNewEmpOreintationLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitNewEmpOreintationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("New Employee Orientation")) {
			Assert.assertTrue(true);
			logger.info("New Employee Orientation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitNewEmpOreintationLink");
			logger.info("New Employee Orientation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 5)
	public void verifyToolkitIndependentContractorLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitIndependantContractorLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Independent Contractors")) {
			Assert.assertTrue(true);
			logger.info("Independent Contractors Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitIndependentContractorLink");
			logger.info("Independent Contractors Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 6)
	public void verifyToolkitBenefitsLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitBenefitsLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Benefits")) {
			Assert.assertTrue(true);
			logger.info("Benefits Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitBenefitsLink");
			logger.info("Benefits Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 7)
	public void verifyToolkitCompensationLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitCompensationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Compensation")) {
			Assert.assertTrue(true);
			logger.info("Compensation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitCompensationLink");
			logger.info("Compensation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 8)
	public void verifyToolkitCOBRALink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitCOBRALink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("COBRA")) {
			Assert.assertTrue(true);
			logger.info("COBRA Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitCOBRALink");
			logger.info("COBRA Page-->>Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 9)
	public void verifyToolkitLeaveOfAbsenceLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitLeaveOfAbsenceLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Leave of Absence")) {
			Assert.assertTrue(true);
			logger.info("Leave of Absence Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitLeaveOfAbsenceLink");
			logger.info("Leave of Absence Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 10)
	public void verifyToolkitWorkersCompensationLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitWorkersCompensationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Workers")) {
			Assert.assertTrue(true);
			logger.info("Worker's Compensation Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitWorkersCompensationLink");
			logger.info("Worker's Compensation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 11)
	public void verifyToolkitUnemploymentCompensationLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitUnemploymentCompensationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Unemployment Compensation")) {
			Assert.assertTrue(true);
			logger.info("Unemployment Compensation Page is displayed");
		} else {
			captureScreenshot(driver,
					"verifyToolkitUnemploymentCompensationLink");
			logger.info("Unemployment Compensation Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 12)
	public void verifyToolkitACALink() throws IOException, InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitACALink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Affordable Care Act")) {
			Assert.assertTrue(true);
			logger.info("Affordable Care Act (ACA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitACALink");
			logger.info("Affordable Care Act (ACA) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 13)
	public void verifyToolkitDisciplineLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitDisciplineLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Discipline")) {
			Assert.assertTrue(true);
			logger.info("Discipline Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitDisciplineLink");
			logger.info("Discipline Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 14)
	public void verifyToolkitTerminationLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitTerminationLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Termination")) {
			Assert.assertTrue(true);
			logger.info("Termination Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitTerminationLink");
			logger.info("Termination Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 15)
	public void verifyToolkitPerformanceMgmtLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitPerformanceMgmtLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Performance Management")) {
			Assert.assertTrue(true);
			logger.info("Performance Management Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitPerformanceMgmtLink");
			logger.info("Performance Management Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 16)
	public void verifyToolkitSexualHarassmentLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitSexualHarassmentLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Sexual Harassment Prevention")) {
			Assert.assertTrue(true);
			logger.info("Sexual Harassment Prevention Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitSexualHarassmentLink");
			logger.info("Sexual Harassment Prevention Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 17)
	public void verifyToolkitHBAndPoliciesLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitHBAndPoliciesLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Handbooks")) {
			Assert.assertTrue(true);
			logger.info("Handbooks and Policies Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitHBAndPoliciesLink");
			logger.info("Handbooks and Policies Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 18)
	public void verifyToolkitRecordKeepingLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitRecordKeepingLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Recordkeeping")) {
			Assert.assertTrue(true);
			logger.info("Recordkeeping Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitRecordKeepingLink");
			logger.info("Recordkeeping Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 19)
	public void verifyToolkitFLMALink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitFLMALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Family and Medical Leave Act")) {
			Assert.assertTrue(true);
			logger.info("Family and Medical Leave Act (FMLA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitFLMALink");
			logger.info("Family and Medical Leave Act (FMLA) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 20)
	public void verifyToolkitEEOLink() throws IOException, InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitEEOLink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Equal Employment Opportunity (EEO)")) {
			Assert.assertTrue(true);
			logger.info("Equal Employment Opportunity (EEO) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitEEOLink");
			logger.info("Equal Employment Opportunity (EEO) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 21)
	public void verifyToolkitFederalContractorReqLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitFederalContractorReqLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Federal Contractor Requirements")) {
			Assert.assertTrue(true);
			logger.info("Federal Contractor Requirements Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitFederalContractorReqLink");
			logger.info("Federal Contractor Requirements Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 22)
	public void verifyToolkitADALink() throws IOException, InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitADALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Americans with Disabilities Act (ADA)")) {
			Assert.assertTrue(true);
			logger.info("Americans with Disabilities Act (ADA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitADALink");
			logger.info("Americans with Disabilities Act (ADA)-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 23)
	public void verifyToolkitFLSALink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitFLSALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains("Fair Labor Standards Act (FLSA)")) {
			Assert.assertTrue(true);
			logger.info("Fair Labor Standards Act (FLSA) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitFLSALink");
			logger.info("Fair Labor Standards Act (FLSA)-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 24)
	public void verifyToolkitOSHALink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitOSHALink(driver);
		Thread.sleep(1000);
		if (driver.getTitle().contains(
				"Occupational Safety and Health Act (OSH Act)")) {
			Assert.assertTrue(true);
			logger.info("Occupational Safety and Health Act (OSH Act) Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitOSHALink");
			logger.info("Occupational Safety and Health Act (OSH Act) Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 25)
	public void verifyToolkitImigrationAndEVerifyLink() throws IOException,
			InterruptedException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnToolkitImigrationAndEVerifyLink(driver);
		Thread.sleep(2000);
		if (driver.getTitle().contains("Immigration")) {
			Assert.assertTrue(true);
			logger.info("Immigration and E-Verify Page is displayed");
		} else {
			captureScreenshot(driver, "verifyToolkitImigrationAndEVerifyLink");
			logger.info("Immigration and E-Verify Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}
}
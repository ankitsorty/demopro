package com.runhr411.testcases;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;

public class VerifyAllLinks extends BaseClass {
	@Test
	public void verifyalltheLinksOnPage() throws InterruptedException {
		HomePage hp = new HomePage(driver);
		commonHomePageDetails();
		hp.clickOnMyHrProfileLink();
		List<WebElement> link = driver.findElements(By.tagName("a"));
		System.out.println(link.size());
		ArrayList<String> hrefs = new ArrayList<String>();
		for (WebElement var : link) {
			System.out.println(var.getText());
			System.out.println(var.getAttribute("href"));
			hrefs.add(var.getAttribute("href"));
			System.out.println("*************************************");
		}
		int i = 0;
		for (String href : hrefs) {
			driver.navigate().to(href);
			System.out.println((++i) + ": navigated to URL with href: " + href);
			Thread.sleep(3000); // To check if the navigation is happening
								// properly.
			System.out
					.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		}

	}
}

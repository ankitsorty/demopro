package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.utilities.ReadConfig;

public class VerifyHomepageTitle_TC_001 extends BaseClass {

	ReadConfig readconfig = new ReadConfig();

	@Test
	public void VerifyHomepageTitleTest() throws InterruptedException, IOException {
		commonHomePageDetails();
		if (driver.getTitle().contains(readconfig.getHomePageTitle())) {
			Assert.assertTrue(true);
			logger.info("Client is valid client and landed on home page of HR411 application");
		} else {
			captureScreenshot(driver, "VerifyHomepageTitleTest");
			logger.info("Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}
	
}

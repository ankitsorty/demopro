package com.runhr411.testcases;

import java.io.IOException;



import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class ComplianceGeneralNavigations_TC_004 extends BaseClass {

	ReadConfig readconfig = new ReadConfig();

	@Test(priority = 0)
	public void VerifyComplianceDbLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.hoverMouseOverCompliance(driver);
		homepage.ClickOnCmlceAlertCtnLink();
		switchTab(driver);
		Thread.sleep(4000);
		if (driver.getPageSource().contains(readconfig.ComplincedbExternalLink())) {
			Assert.assertTrue(true);
			logger.info("Litters Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceDbLink");
			logger.info("Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}
	
	@Test(priority = 1)
	public void VerifyComplianceUpdatesLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnComplianceUpdatesLink(driver);
		if (driver.getPageSource().contains("Compliance Updates")) {
			Assert.assertTrue(true);
			logger.info("Compliance Updates Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceUpdatesLink");
			logger.info("Compliance Updates Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);

		}
	}
	
	@Test(priority = 2)
	public void VerifyComplianceFederalResourcesLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnComplianceStateFederalLink(driver);
		if (driver.getPageSource().contains("State & Federal Resources")) {
			Assert.assertTrue(true);
			logger.info("State & Federal Resources Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyComplianceFederalResourcesLink");
			logger.info("State & Federal Resources Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}

	@Test(priority = 3)
	public void VerifyAuditComplianceWizardLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnComplianceAuditWizardLink(driver);
		if (driver.getTitle().contains("HR Audit & Compliance Wizard")) {
			Assert.assertTrue(true);
			logger.info("HR Audit & Compliance Wizard Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyAuditComplianceWizardLink");
			logger.info("HR Audit & Compliance Wizard Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority = 4)
	public void VerifyHRCheckupsLink() throws InterruptedException, IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnComplianceHRCheckupsLink(driver);
		if (driver.getPageSource().contains("HR Checkups")) {
			Assert.assertTrue(true);
			logger.info("HR Check-ups Page for compliance DB is displayed");
		} else {
			captureScreenshot(driver, "VerifyHRCheckupsLink");
			logger.info("HR Check-ups Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}
}

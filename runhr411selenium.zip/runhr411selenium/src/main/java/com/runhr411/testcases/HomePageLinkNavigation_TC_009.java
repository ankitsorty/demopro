package com.runhr411.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.runhr411.pageobjects.BaseClass;
import com.runhr411.pageobjects.HomePage;
import com.runhr411.utilities.ReadConfig;

public class HomePageLinkNavigation_TC_009 extends BaseClass{
	
	ReadConfig readconfig = new ReadConfig();
	@Test
	public void verifyHomePageNavigationLink() throws InterruptedException,
			IOException {
		HomePage homepage = new HomePage(driver);
		commonHomePageDetails();
		homepage.clickOnHomePage();
		if (driver.getTitle().contains(readconfig.getControlPanelTitle())) {
			Assert.assertTrue(true);
			logger.info("Home Page is displayed");
		} else {
			captureScreenshot(driver, "verifyHomePageNavigationLink");
			logger.info("Home Page-->Test case is failed due to validation failure");
			Assert.assertTrue(false);
		}
	}
}

package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddJDPost {

	WebDriver ldriver;

	public AddJDPost(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "//div[contains(text() , 'Buys, advertises and resells media space or time.')]")
	WebElement addJDPost;

	public void clickOnaddJDDesc() {
		addJDPost.click();

	}
}
package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HBAccessSetupCompletePage {

	WebDriver ldriver;

	public HBAccessSetupCompletePage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(id = "mySite")
	WebElement mhoLink;
	
	@FindBy(className = "btnVisitOnlineHandBook button button-primary")
	WebElement visitHBOnlinebtn;
	
	@FindBy(className = "btnAcknowledgeTemplate button button-secondary")
	WebElement ackTempBtn;
	
	@FindBy(className = "btnDone button button-secondary")
	WebElement doneBtn;
	
	public void clickOnMHOLink(){
		mhoLink.click();
	}
	
	public void clickOnVisitHBOnlineBtn(){
		visitHBOnlinebtn.click();
	}
	
	public void clickOnAckTemplateBtn(){
		ackTempBtn.click();
	}
	
	public void clickOnDoneBtn(){
		doneBtn.click();
	}
}

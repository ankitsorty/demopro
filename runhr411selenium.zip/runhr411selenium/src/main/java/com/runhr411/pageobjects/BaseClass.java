package com.runhr411.pageobjects;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import com.runhr411.utilities.ReadConfig;

public class BaseClass {

	ReadConfig readconfig = new ReadConfig();
	public String baseURL = readconfig.getApplicationURL();
	public String IID = readconfig.getUserIID();
	public String homepagetitle = readconfig.getHomePageTitle();
	public String adminpaneltitle = readconfig.getAdminPanelTitle();
	public String controlpaneltitle = readconfig.getControlPanelTitle();
	public static WebDriver driver;
	public static Logger logger;
	public int HTTP_RESPONSE_CODE_200 = 200;
	public int HTTP_RESPONSE_CODE_201 = 201;
	public int HTTP_RESPONSE_CODE_401 = 401;
	public int HTTP_RESPONSE_CODE_500 = 500;
	

	@SuppressWarnings("deprecation")
	@Parameters("browser")
	@BeforeMethod
	public void setup(String br) throws Exception {
		logger = Logger.getLogger("runhr411automation");
		PropertyConfigurator.configure("log4j.properties");
		freemarker.log.Logger
				.selectLoggerLibrary(freemarker.log.Logger.LIBRARY_NONE);

		if (br.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					readconfig.getChromeDriverPath());
			driver = new ChromeDriver();
	logger.info("Google Chrome is opened");
		} else if (br.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver",
					readconfig.getFirefoxDiverPath());
			driver = new FirefoxDriver();
			logger.info("Mozilla Firefox is opened");
		} else if (br.equals("ie")) {
			System.setProperty("webdriver.ie.driver",
					readconfig.getieDriverPath());
			driver = new InternetExplorerDriver();
			logger.info("IE is opened");
		}

		driver.manage().timeouts()
				.implicitlyWait(readconfig.getImplicitWait(), TimeUnit.SECONDS);
		driver.get(baseURL);
		logger.info("URL is Launched");
		driver.manage().window().maximize();
		logger.info("Window is maximized");
		driver.manage().deleteAllCookies();
		logger.info("Deleted cookies");
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

	public void captureScreenshot(WebDriver driver, String tcname)
			throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File Source = ts.getScreenshotAs(OutputType.FILE);
		File target = new File(System.getProperty("user.dir")
				+ "\\Screenshots\\" + tcname + ".png");
		FileUtils.copyFile(Source, target);
		System.out.println("Screenshot captured Successfully");
		logger.info("Screenshot Captured for the Failure caused");
	}

	public String randomString() {
		String rndmstr = RandomStringUtils.randomAlphabetic(8);
		return (rndmstr);
	}

	public static String randomNum() {
		String rndmnum = RandomStringUtils.randomNumeric(6);
		return (rndmnum);
	}

	public void switchTab(WebDriver driver) {
		String cuttentTab = driver.getWindowHandle();
		ArrayList<String> newTab = new ArrayList<String>(
				driver.getWindowHandles());
		newTab.remove(cuttentTab);
		driver.switchTo().window(newTab.get(0));
	}

	public void commonHomePageDetails() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.insertIID(IID);
		logger.info("IID is entered in textbox" + " " + IID);
		homepage.submitTokentButton();
		logger.info("Clicked Enter button");
	}
	
	public void accReinstatementdetails() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.insertIID(readconfig.getAdminIID());
		logger.info("IID is entered in textbox" + " " + IID);
		homepage.submitTokentButton();
		logger.info("Clicked Enter button");
	}

	public void commonHomePageEssentialDetails() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.insertIID(readconfig.getEssentialIID());
		logger.info("IID is entered in textbox");
		homepage.submitTokentButton();
		logger.info("Clicked Enter button");
	}
	
	public void commonHomePageADPEnhancedPayrollDetails() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.insertIID(readconfig.getADPEnhancePayrollIID());
		logger.info("IID is entered in textbox");
		homepage.submitTokentButton();
		logger.info("Clicked Enter button");
	}
	
	public void commonHomePageEnhancedDetails() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.insertIID(readconfig.getEnhancedIID());
		logger.info("IID is entered in textbox");
		homepage.submitTokentButton();
		logger.info("Clicked Enter button");
	}
	
	public void commonHomePageHR411CompleteDetails() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.insertIID(readconfig.getAdminIID());
		logger.info("IID is entered in textbox");
		homepage.submitTokentButton();
		logger.info("Clicked Enter button");
	}
	
	public void commonHomePageStarterDetails() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.insertIID(readconfig.getstarterIID());
		logger.info("IID is entered in textbox");
		homepage.submitTokentButton();
		logger.info("Clicked Enter button");
	}

	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	@SuppressWarnings("unused")
	private static int getRandomNumberInBetween(int lowerBound, int upperBound) {
		Random r = new Random();
		return (r.nextInt(upperBound) + lowerBound);
	}

	public static String getUTCCuttentTimestamp() {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		df.setTimeZone(tz);
		String authtime = df.format(new Date());
		System.out.println(authtime);
		return authtime;
	}

}

package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class JDFindTemplate {

	WebDriver ldriver;

	public JDFindTemplate(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "//a[contains(text() , 'Business & Management')]")
	WebElement addJDTemp;

	public void clickOnaddJDDesc() {
		addJDTemp.click();

	}
}
package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminPanel {

	WebDriver ldriver;

	public AdminPanel(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(id = "hpid")
	WebElement searchBar;

	@FindBy(xpath = "//input[@type ='submit']")
	WebElement getuser;
	
	@FindBy(xpath = "//*[@id='datalist']/tbody/tr[2]")
	WebElement clickuser;

	public String testAdminIID(String IID) {
		searchBar.sendKeys(IID);
		return IID;
	}

	public void clickOnGetUser() {
		getuser.click();

	}
	
	public void clickOnGetUserRecord() {
		clickuser.click();

	}
}

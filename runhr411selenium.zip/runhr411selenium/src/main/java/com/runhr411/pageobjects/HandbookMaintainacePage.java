package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HandbookMaintainacePage {
	WebDriver ldriver;

	public HandbookMaintainacePage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "//p[contains(text(), 'Setup/Manage')]")
	WebElement empAccesstxt;
	
	@FindBy(xpath = "//p[contains(text(), 'Policy')]")
	WebElement policyToolkittxt;
	
	@FindBy(id = "btnDownloadHandbookTrial")
	WebElement HBDownloadbtn;
	
	@FindBy(id = "dashboardHomeGetHelp")
	WebElement getHelpNowbtn;
	
	public void clickOnEmpAccessLogo(){
		empAccesstxt.click();
	}
	
	public void clickOnPolicyLogo(){
		policyToolkittxt.click();
	}
	
	public void clickOnDownloadHBBtn(){
		HBDownloadbtn.click();
	}
	
	public void clickOnGetHelpNowBtn(){
		getHelpNowbtn.click();
	}
}

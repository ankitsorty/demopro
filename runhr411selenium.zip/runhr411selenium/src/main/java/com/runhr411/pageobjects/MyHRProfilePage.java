package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class MyHRProfilePage {

	public WebDriver driver;

	public MyHRProfilePage(WebDriver rdriver1) {
		driver = rdriver1;
		PageFactory.initElements(rdriver1, this);
	}

	@FindBy(id = "tab_tablist_dijit_layout_ContentPane_2")
	WebElement contactInfoTab;

	@FindBy(id = "tab_tablist_dijit_layout_ContentPane_3")
	WebElement companyInfoTab;

	@FindBy(id = "tab_tablist_dijit_layout_ContentPane_4")
	WebElement practiceTab;
	
	@FindBy(id = "saveChangesContactInfoButton")
	WebElement saveBtn;
	
	@FindBy(id = "saveChangesCompanyInfoButton")
	WebElement saveBtn1;
	
	@FindBy(id = "saveChangesPracticesButton")
	WebElement saveBtn2;

	@FindBy(id = "firstname")
	WebElement firstName;

	@FindBy(id = "lastname")
	WebElement lastName;

	@FindBy(id = "workemail")
	WebElement workEmail;

	@FindBy(id = "workphone")
	WebElement workPhone;

	@FindBy(id = "title")
	WebElement title;

	@FindBy(id = "hr_contact_email")
	WebElement hr_contact_email;
	
	@FindBy(id = "hr_contact_name")
	WebElement hr_contact_name;

	@FindBy(id = "hr_contact_phone")
	WebElement hr_contact_phone;

	@FindBy(id = "hr_contact_title")
	WebElement hr_contact_title;

	@FindBy(id = "industry")
	WebElement industry;

	@FindBy(id = "workstateorprovince")
	WebElement workstateorprovince;

	@FindBy(name = "additional_states1")
	WebElement additional_states1;

	@FindBy(xpath = "//input[@name = 'currenthandbook'  and  @value = 'yes']")
	WebElement radioButtonYes;

	@FindBy(xpath = "//input[@name = 'currenthandbook'  and  @value = 'no']")
	WebElement radioButtonNo;

	public void clickOnContactInfoTab() {
		contactInfoTab.click();
	}

	public void clickOnCompanyInfoTab() {
		companyInfoTab.click();
	}

	public void clickOnPracticeTab() {
		practiceTab.click();
	}
	
	public void clickOnContactSaveButton() {
		Actions action = new Actions(driver);
		action.moveToElement(saveBtn).click(saveBtn).build()
		.perform();
	}
	
	public void clickOnCompanySaveButton() {
		Actions action = new Actions(driver);
		action.moveToElement(saveBtn1).click(saveBtn1).build()
		.perform();
	}
	
	public void clickOnPracticeSaveButton() {
		Actions action = new Actions(driver);
		action.moveToElement(saveBtn2).click(saveBtn2).build()
		.perform();
	}

	public String getContactFirstname(String fname) {
		firstName.clear();
		firstName.sendKeys(fname);
		return fname;
	}

	public String getContactLastname(String lname) {
		lastName.clear();
		lastName.sendKeys(lname);
		return lname;
	}
	
	public String getContactHRname(String hrname) {
		hr_contact_name.clear();
		hr_contact_name.sendKeys(hrname);
		return hrname;
	}

	public String getContactWorkEmail(String wemail) {
		workEmail.clear();
		workEmail.sendKeys(wemail);
		return wemail;
	}

	public String getContactWorkPhone(String wphone) {
		workPhone.clear();
		workPhone.sendKeys(wphone);
		return wphone;
	}

	public String getContactTitle(String title1) {
		title.clear();
		title.sendKeys(title1);
		return title1;
	}

	public String getContactHREmail(String hremail) {
		hr_contact_email.clear();
		hr_contact_email.sendKeys(hremail);
		return hremail;
	}

	public String getContactHRPhone(String hrphone) {
		hr_contact_phone.clear();
		hr_contact_phone.sendKeys(hrphone);
		return hrphone;
	}

	public String getContactHRTitle(String title) {
		hr_contact_title.clear();
		hr_contact_title.sendKeys(title);
		return title;
	}

	public void getCompanyState(int index) {
		Select dropDown = new Select(workstateorprovince);
		dropDown.selectByIndex(index);
	}
	
	public void getContactIndustry(int index) {
		Select dropDown = new Select(industry);
		dropDown.selectByIndex(index);
	}

	public void getContactAdditionalState(int index) {
		Select dropDown1 = new Select(additional_states1);
		dropDown1.selectByIndex(index);
	}

	public void checkPracticeRadioButton() {
		boolean rbtn = radioButtonYes.isSelected();
		if (rbtn) {
			radioButtonNo.click();
		} else {
			radioButtonYes.click();
		}

	}
}

package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class JDCreationForm {

	WebDriver ldriver;

	public JDCreationForm(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "//span[@class = 'banner']/following-sibling::div/i[@class = 'fa fa-pencil']")
	WebElement editJobTitle;

	@FindBy(id = "department")
	WebElement dept;

	@FindBy(id = "reportsTo")
	WebElement reportsTo;

	@FindBy(id = "flsaDropdown")
	WebElement selectbtn;

	@FindBy(xpath = "//a[contains(text(), 'Non Exempt')]")
	WebElement selectdropdown;

	@FindBy(id = "preparedBy")
	WebElement preparedBy;

	@FindBy(id = "approvedBy")
	WebElement approvedBy;

	@FindBy(id = "btnHeaderSectionSave")
	WebElement saveBtn;

	@FindBy(xpath = "//div[@class = 'section-content']/preceding-sibling::div/div/i")
	WebElement editJobDesc;

	@FindBy(xpath = "//li[contains(text(),'Buys, advertises and resells media space or time.')]/ancestor::body[@id = 'tinymce']")
	WebElement sendJobDesc;

	@FindBy(xpath = "//*[@id'section-edit-262610']/div[5]/button[1]")
	WebElement saveJobDesc;

	public void editJDTitle() {
		editJobTitle.click();
	}

	public String setJDDept(String dept1) {
		dept.sendKeys(dept1);
		return dept1;
	}

	public String setJDReportsTo(String report) {
		reportsTo.sendKeys(report);
		return report;
	}

	public void selectDDvalue(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(selectbtn).click(selectdropdown).build().perform();
	}

	public String setJDApprovedBy(String prepare) {
		preparedBy.sendKeys(prepare);
		return prepare;
	}

	public String setJDPreparedBy(String approve) {
		approvedBy.sendKeys(approve);
		return approve;
	}
	
	public void saveJDTitle(){
		saveBtn.click();
	}
	
	public void editJobDescription(){
		editJobDesc.click();
	}
	
	public String setJobDescription(String Desc){
		sendJobDesc.sendKeys(Desc);
		return Desc;
	}
	
	public void saveJDDesc(){
		saveJobDesc.click();
	}

}

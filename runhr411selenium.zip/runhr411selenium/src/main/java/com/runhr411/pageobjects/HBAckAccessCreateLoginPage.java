package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HBAckAccessCreateLoginPage {
	
	WebDriver ldriver;

	public HBAckAccessCreateLoginPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(id = "empAccUrl")
	WebElement loginurl;
	
	@FindBy(id = "empAccCompID")
	WebElement cmpnyIdentifier;

	@FindBy(id = "empAccPass")
	WebElement password;
	
	@FindBy(xpath = "//a[contains(text(),'Next')]")
	WebElement nextBtn;
	
	@FindBy(className = "btnCancelEmpAcc button button-secondary")
	WebElement cancelBtn;
	
	@FindBy(id = "urlInvalid")
	WebElement invalidURl;
	
	@FindBy(id = "CompIDInvalid")
	WebElement companyIdInvalid;
	
	public void getLoginURL(String url){
		loginurl.clear();
		loginurl.sendKeys(url);
	}
	
	public void getCompanyIdentifier(String id){
		cmpnyIdentifier.clear();
		cmpnyIdentifier.sendKeys(id);
	}
	
	public void getPassword(String pwd){
		password.clear();
		password.sendKeys(pwd);
	}
	
	public void clickOnNexttBtn(){
		nextBtn.click();
	}
	
	public void clickOnCancelBtn(){
		cancelBtn.click();
	}
	
	public String getLoginfieldMsg(){
		return invalidURl.getText();
	}
	
	public String getCompanyIDfieldMsg(){
		return companyIdInvalid.getText();
	}
}
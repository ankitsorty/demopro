package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserManagenentHomePage {
	WebDriver ldriver;

	public UserManagenentHomePage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(xpath = "//div[contains(text(), 'Archive Account')]")
	WebElement archiveAcc;
	
	
	public void clickOnArchiveAccount(){
		archiveAcc.click();
	}


}

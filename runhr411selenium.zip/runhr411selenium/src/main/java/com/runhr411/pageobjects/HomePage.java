package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	public WebDriver ldriver;

	public HomePage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(id = "__IIDtest")
	WebElement iidBox;

	@FindBy(xpath = "//input[@type='submit']")
	WebElement submitTokentButton;

	@FindBy(xpath = "//span[contains(text(), 'Home')]")
	WebElement homePagelink;

	@FindBy(id = "backgroundchecks")
	WebElement bgcLink;
	
	@FindBy(id = "210113201")
	WebElement bccheckLink;
	
	@FindBy(id = "210113202")
	WebElement bcscreeningLink;

	@FindBy(xpath = "//*[@id= 'hrcomplianceRt' or @id = 'hrcompliance']")
	static WebElement complianceLink;

	@FindBy(xpath = "//a[contains(text(), 'Compliance Database')]")
	static WebElement complianceDBLink;
	
	@FindBy(id = "534521")
	WebElement complianceUpdateLink;
	
	@FindBy(id = "dasd34f")
	WebElement stateandfederalresLink;
	
	@FindBy(id = "rxf34s")
	WebElement auditandcompliancewizardLink;
	
	@FindBy(id = "5645g")
	WebElement hrCheckupsLink;

	@FindBy(xpath = "//a[@id='tooltipDlgLink']/p")
	static WebElement complianceDBAlertContinueLink;

	@FindBy(id = "hrlibrary")
	WebElement libraryLink;
	
	@FindBy(id = "2cc2131a")
	WebElement libraryformsAndDocsLink;
	
	@FindBy(id = "2cd2131")
	WebElement libraryNewHirePaperWorkLink;
	
	@FindBy(id = "22e131")
	WebElement libraryTipOfTheWeekLink;
	
	@FindBy(id = "221f31")
	WebElement libraryHRNewsLetterLink;
	
	@FindBy(id = "221b31")
	WebElement libraryHRDictionaryLink;
	
	@FindBy(id = "22151")
	WebElement libraryHRTrainingLink;
	
	@FindBy(xpath = "//a[@title = 'HR & Product Webcasts']")
	WebElement libWebinarLink;

	@FindBy(id = "hbw")
	WebElement hbwLink;
	
	@FindBy(id = "210113211")
	WebElement hbLink;

	@FindBy(xpath = "//span[contains(text(), 'HR HelpDesk')]")
	WebElement hrHeplDeskIcon;

	@FindBy(xpath = "//a[@class='scprimary']//span[contains(text(), 'Background Checks')]")
	WebElement bgCheckIcon;

	@FindBy(xpath = "//span[contains(text(),'New Hire Paperwork')]")
	WebElement newHirePaperWorkIcon;

	@FindBy(xpath = "//a[@class='scprimary']//span[contains(text(),'Employee Handbook')]")
	WebElement employeeHBIcon;

	@FindBy(id = "jdw")
	WebElement jobDesc;

	@FindBy(id = "22131")
	WebElement myJobDescLink;
	
	@FindBy(id = "22131a")
	WebElement findTemplateLink;
	
	@FindBy(xpath = "//a[@class = 'adminButton' and @title = 'My HR Profile']")
	WebElement myHrProfilelink;

	@FindBy(xpath = "//a[@class = 'adminButton' and @title = 'HR HelpDesk']")
	WebElement hrHeplDeskLink;

	@FindBy(xpath = "//a[@class = 'adminButton' and @title = 'Support Center']")
	WebElement supportCentreLink;

	@FindBy(xpath = "//a[@class = 'adminButton' and @title = 'Logout']")
	WebElement logoutLink;

	@FindBy(xpath = "//a[@title = 'Forms & Documents']")
	WebElement formsAndDocs;
	
	@FindBy(id = "hrtoolkits")
	WebElement toolkitLink;
	
	@FindBy(id = "110113201")
	WebElement hiringLink;
	
	@FindBy(id = "110113202")
	WebElement jdLink;
	
	@FindBy(id = "110113203")
	WebElement intwerviewingLink;
	
	@FindBy(id = "210118327")
	WebElement BCScreeningLink;
	
	@FindBy(id = "210118327a")
	WebElement newEmpOreintationLink;
	
	@FindBy(id = "210118327b")
	WebElement independantContractorLink;
	
	@FindBy(id = "110110201")
	WebElement benefitsLink;
	
	@FindBy(id = "110110203")
	WebElement compensationLink;
	
	@FindBy(id = "110110204")
	WebElement cobraLink;
	
	@FindBy(id = "210118326")
	WebElement leaveOfAbsenceLink;
	
	@FindBy(id = "210118326a")
	WebElement workerCompensationLink;
	
	@FindBy(id = "210118326b")
	WebElement umemplymentCompensationLink;
	
	@FindBy(id = "210118326c")
	WebElement acaLink;
	
	@FindBy(id = "110110301")
	WebElement disciplineLink;
	
	@FindBy(id = "110110301a")
	WebElement terminationLink;
	
	@FindBy(id = "110110305")
	WebElement performanceMLgmtink;
	
	@FindBy(id = "110110305a")
	WebElement sexualHarassmentLink;
	
	@FindBy(id = "110110302a")
	WebElement hbandPoliciesLink;
	
	@FindBy(id = "110110302x")
	WebElement recordkeepingLink;
	
	@FindBy(id = "110110302b")
	WebElement flmaLink;
	
	@FindBy(id = "110110302c")
	WebElement eeoLink;
	
	@FindBy(id = "110110302d")
	WebElement federalContractorReqLink;
	
	@FindBy(id = "110110302e")
	WebElement adaLink;
	
	@FindBy(id = "110110302f")
	WebElement flsaLink;
	
	@FindBy(id = "110110302h")
	WebElement oshaLink;
	
	@FindBy(id = "110110302k")
	WebElement immigrationLink;
	
	@FindBy(xpath = "//*[@id='adminButton-button']/div[2]/li/a")
	WebElement adminPanelHome;
	
	@FindBy(xpath = "//a[contains(text(), 'Control Panel')]")
	WebElement controlPanel;
	
	public String insertIID(String iid) {
		iidBox.sendKeys(iid);
		return iid;
	}
	
	public void clickOnAdminPanelLink1() {
		adminPanelHome.click();
		
	}
	public void clickOnControlPanelLink() {
		controlPanel.click();
		
	}

	public void clickOnHomePage() {
		homePagelink.click();
	}

	public void submitTokentButton() {
		submitTokentButton.click();
	}

	public void clickOnBGCLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(bgcLink).click(bccheckLink).build()
		.perform();
	}
	
	public void clickOnBGCScreeningLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(bgcLink).click(bcscreeningLink).build()
		.perform();
	}

	public void clickOnToolkitHiringLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(hiringLink).build()
		.perform();
	}
	
	public void clickOnToolkitJDLink(WebDriver driver) {
			Actions action = new Actions(driver);
			action.moveToElement(toolkitLink).click(jdLink).build()
			.perform();	
	}
	
	public void clickOnToolkitInterviewingLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(intwerviewingLink).build()
		.perform();	
}

	public void clickOnToolkitBCScreeningLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(BCScreeningLink).build()
		.perform();	
}
	
	public void clickOnToolkitNewEmpOreintationLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(newEmpOreintationLink).build()
		.perform();	
}
	
	public void clickOnToolkitIndependantContractorLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(independantContractorLink).build()
		.perform();	
}
	
	public void clickOnToolkitBenefitsLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(benefitsLink).build()
		.perform();	
}
	
	public void clickOnToolkitCompensationLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(compensationLink).build()
		.perform();	
}
	
	public void clickOnToolkitCOBRALink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(cobraLink).build()
		.perform();	
}
	
	public void clickOnToolkitLeaveOfAbsenceLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(leaveOfAbsenceLink).build()
		.perform();	
}
	public void clickOnToolkitWorkersCompensationLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(workerCompensationLink).build()
		.perform();	
}
	
	public void clickOnToolkitUnemploymentCompensationLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(umemplymentCompensationLink).build()
		.perform();	
}
	
	public void clickOnToolkitACALink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(acaLink).build()
		.perform();	
}
	public void clickOnToolkitDisciplineLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(disciplineLink).build()
		.perform();	
}
	
	public void clickOnToolkitTerminationLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(terminationLink).build()
		.perform();	
}
	
	public void clickOnToolkitPerformanceMgmtLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(performanceMLgmtink).build()
		.perform();	
}
	
	public void clickOnToolkitSexualHarassmentLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(sexualHarassmentLink).build()
		.perform();	
}
	
	public void clickOnToolkitHBAndPoliciesLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(hbandPoliciesLink).build()
		.perform();	
}
	
	public void clickOnToolkitRecordKeepingLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(recordkeepingLink).build()
		.perform();	
}
	
	public void clickOnToolkitFLMALink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(flmaLink).build()
		.perform();	
}
	
	public void clickOnToolkitEEOLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(eeoLink).build()
		.perform();	
}
	
	public void clickOnToolkitFederalContractorReqLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(federalContractorReqLink).build()
		.perform();	
}
	
	public void clickOnToolkitADALink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(adaLink).build()
		.perform();	
}
	
	public void clickOnToolkitFLSALink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(flsaLink).build()
		.perform();	
}
	
	public void clickOnToolkitOSHALink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(oshaLink).build()
		.perform();	
}
	
	public void clickOnToolkitImigrationAndEVerifyLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(toolkitLink).click(immigrationLink).build()
		.perform();	
}

	
	public void hoverMouseOverLibrary(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(libraryLink).click(libWebinarLink).build()
				.perform();
	}
	
	public void clickOnLibraryFormsAndDocsLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(libraryLink).click(libraryformsAndDocsLink).build()
				.perform();
	}
	
	public void clickOnLibraryNewHirePaperWorkLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(libraryLink).click(libraryNewHirePaperWorkLink).build()
				.perform();
	}
	
	public void clickOnLibraryTipOfTheWeekLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(libraryLink).click(libraryTipOfTheWeekLink).build()
				.perform();
	}
	
	public void clickOnLibraryHRNewsLetterLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(libraryLink).click(libraryHRNewsLetterLink).build()
				.perform();
	}
	
	public void clickOnLibraryHRDictionaryLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(libraryLink).click(libraryHRDictionaryLink).build()
				.perform();
	}
	
	public void clickOnLibraryHRTrainingLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(libraryLink).click(libraryHRTrainingLink).build()
				.perform();
	}

	public void hoverMouseOverCompliance(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(complianceLink).click(complianceDBLink).build()
				.perform();
	}
	
	public void clickOnComplianceUpdatesLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(complianceLink).click(complianceUpdateLink).build()
				.perform();
	}
	
	public void clickOnComplianceStateFederalLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(complianceLink).click(stateandfederalresLink).build()
				.perform();
	}
	
	public void clickOnComplianceAuditWizardLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(complianceLink).click(auditandcompliancewizardLink).build()
				.perform();
	}
	
	public void clickOnComplianceHRCheckupsLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(complianceLink).click(hrCheckupsLink).build()
				.perform();
	}


	public void ClickOnCmlceAlertCtnLink() {
		complianceDBAlertContinueLink.click();
	}

	public void hoverMouseOverBGCheck() {
		bgcLink.click();
	}

	public void clickOnMyJobDescriptionLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(jobDesc).click(myJobDescLink).build()
				.perform();
	}
	
	public void clickOnMyJobDescriptionFindTemplateLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(jobDesc).click(findTemplateLink).build()
				.perform();
	}
	
	public void clickOnEMPHandbookLink(WebDriver driver) {
		Actions action = new Actions(driver);
		action.moveToElement(hbwLink).click(hbLink).build()
				.perform();
	}


	public void clickOnMyHrProfileLink() {
		myHrProfilelink.click();
	}

	public void clickOnHrHeplDeskLink() {
		hrHeplDeskLink.click();
	}

	public void clickOnSupportCentreLink() {
		supportCentreLink.click();
	}

	public void clickOnLogoutLink() {
		logoutLink.click();
	}

	public void clickOnMyEmpHBKIcon() {
		employeeHBIcon.click();
	}

	public void clickOnBGCheckIcon() {
		bgCheckIcon.click();
	}

	public void clickOnNewHirePaperWorkIcon() {
		newHirePaperWorkIcon.click();
	}

	public void clickOnHrHeplDeskIcon() {
		hrHeplDeskIcon.click();
	}
	
}

package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HbAccessWelcomePage {
	WebDriver ldriver;

	public HbAccessWelcomePage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(id = "mceContentBody ")
	WebElement welcometxt;
	
	@FindBy(xpath = "//a[contains(text(),'Next')]")
	WebElement nextBtnn;
	
	@FindBy(className = "btnCancelEmpAcc button button-secondary")
	WebElement cancelBtn;
	
	@FindBy(className = "btnBackEmpAcc button button-secondary")
	WebElement prevoiusBtn;
	
	public void getWelcomeText(String welcmtxt){
		welcometxt.sendKeys(welcmtxt);
	}
	
	public void clickOnnNextBtn(){
		nextBtnn.click();
	}
	
	public void clickOnCancelBtn(){
		cancelBtn.click();
	}
	
	public void clickOnPreviousBtn(){
		prevoiusBtn.click();
	}
}

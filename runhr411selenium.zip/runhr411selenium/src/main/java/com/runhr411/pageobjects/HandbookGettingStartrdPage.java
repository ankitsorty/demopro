package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HandbookGettingStartrdPage {

	WebDriver ldriver;

	public HandbookGettingStartrdPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
 
	@FindBy(xpath = "//button[contains(text(), 'Continue')]")
	WebElement continuebtn;
	
	@FindBy(id = "wizardCompanyName")
	WebElement companyNameBox;

	@FindBy(id = "wizardIndustry1")
	WebElement industrtType;

	@FindBy(id = "wizardNumberOfEmployees")
	WebElement noOfEmp;

	@FindBy(id = "btnGetStarted button button-primary")
	WebElement getStartedBtn;

	public void clickOnContinuebtn() {
		continuebtn.click();
	}
	
	public void enterCompanyName(String compName) {
		companyNameBox.sendKeys(compName);
	}

	public void selectIndustryType() {
		 Select select = new Select(industrtType);
		 select.selectByIndex(1);
		 industrtType.sendKeys();
	}

	public void enterNoOfEmployees(String empNum) {
		noOfEmp.sendKeys(empNum);
	}

	public void clickOnGetStarted() {
		getStartedBtn.click();
	}
}
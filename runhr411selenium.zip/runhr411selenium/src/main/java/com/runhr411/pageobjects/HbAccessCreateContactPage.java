package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HbAccessCreateContactPage {

	WebDriver driver;

	public HbAccessCreateContactPage(WebDriver rdriver) {
		driver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(id = "empAccContactName")
	WebElement empContactName;

	@FindBy(id = "empAccContactTitle")
	WebElement empContactTitle;

	@FindBy(id = "empAccContactPhone")
	WebElement empContactPhone;

	@FindBy(xpath = "empAccContactAltPhone")
	WebElement empContactAltPhone;

	@FindBy(id = "empAccContactEmail")
	WebElement empContactEmail;

	@FindBy(id = "empAccContactPhoneExt")
	WebElement empContactPhoneExt;

	@FindBy(id = "empAccContactAltPhoneExt")
	WebElement empContactAltPhoneExt;

	@FindBy(className = "btnNextEmpAcc button button-primary")
	WebElement nextBtn;

	@FindBy(className = "btnCancelEmpAcc button button-secondary")
	WebElement cancelBtn;

	@FindBy(className = "btnBackEmpAcc button button-secondary")
	WebElement prevoiusBtn;
	
	@FindBy(xpath = "//div[contains(text(), 'Tap to dismiss')]")
	WebElement quickGuide;
	
	public void dismissQuickGuide() {
		Actions action = new Actions(driver);
		action.moveToElement(quickGuide).click(quickGuide).build()
		.perform();
}
	

	public void setEmpContactName(String empName) {
		empContactName.clear();
		empContactName.sendKeys(empName);
	}

	public void setEmpContactTitle(String empTitle) {
		empContactTitle.clear();
		empContactTitle.sendKeys(empTitle);
	}

	public void setEmpContactPhone(String empPhone) {
		empContactPhone.clear();
		empContactPhone.sendKeys(empPhone);
	}

	public void setEmpContactAltPhone(String empAltPhone) {
		empContactAltPhone.clear();
		empContactAltPhone.sendKeys(empAltPhone);
	}

	public void setEmpContactEmail(String empEmail) {
		empContactEmail.clear();
		empContactEmail.sendKeys(empEmail);
	}

	public void setEmpContactPhoneExt(String empPhoneExt) {
		empContactPhoneExt.clear();
		empContactPhoneExt.sendKeys(empPhoneExt);
	}

	public void setEmpContactAltPhoneExt(String empAltPhoneExt) {
		empContactAltPhoneExt.clear();
		empContactAltPhoneExt.sendKeys(empAltPhoneExt);
	}

	public void clickOnNextBtn() {
		Actions action = new Actions(driver);
		action.moveToElement(nextBtn).click(nextBtn).build()
		.perform();
	}

	public void clickOnCancelBtn() {
		cancelBtn.click();
	}

	public void clickOnPreviousBtn() {
		prevoiusBtn.click();
	}

}
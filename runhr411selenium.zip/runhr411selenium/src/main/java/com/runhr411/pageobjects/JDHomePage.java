package com.runhr411.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class JDHomePage {

	WebDriver ldriver;

	public JDHomePage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "//div[@id='addCardActionPlus']/i")
	WebElement addJDDesc;

	public void clickOnaddJDDesc() {
		addJDDesc.click();

	}
}

package com.runhr411.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadConfig {

	Properties prop;

	public ReadConfig() {

		File src = new File("./Configurations/config.properties");

		try {
			FileInputStream fis = new FileInputStream(src);
			prop = new Properties();
			prop.load(fis);
		} catch (Exception e) {
			System.out.println("Exception is " + e.getMessage());
		}
	}

	public String getApplicationURL() {

		String url = prop.getProperty("baseURL");
		System.out.println(url);
		return url;

	}

	public String getUserIID() {
		String iid = prop.getProperty("tesiid");
		System.out.println(iid);
		return iid;
	}

	public String getHomePageTitle() {
		String tilte = prop.getProperty("homepagetitle");
		return tilte;
	}
	
	public String getAdminIID() {
		String aiid = prop.getProperty("adminiid");
		return aiid;
	}

	public String getAdminPanelTitle() {
		String admntitle = prop.getProperty("adminpaneltitle");
		return admntitle;
	}

	public String getControlPanelTitle() {
		String ctrtitle = prop.getProperty("controlpaneltitle");
		return ctrtitle;
	}

	public String getChromeDriverPath() {
		String chpath = prop.getProperty("chromepath");
		return chpath;
	}

	public String getFirefoxDiverPath() {
		String ffpath = prop.getProperty("firefoxpath");
		return ffpath;
	}

	public String getieDriverPath() {
		String iepath = prop.getProperty("iepath");
		return iepath;
	}

	public long getImplicitWait() {
		prop.getProperty("implicitwait");
		return 0;
	}

	public String getHostName() {
		String hnmae = prop.getProperty("hostname");
		return hnmae;

	}

	public String getEnvironment() {
		String env = prop.getProperty("environment");
		return env;
	}

	public String getUserName() {
		String uname = prop.getProperty("username");
		return uname;
	}

	public String getExtentReportTiltle() {
		String extentreporttitle = prop.getProperty("documenttitle");
		return extentreporttitle;
	}

	public String getExtentReportName() {
		String extentreportname = prop.getProperty("reportname");
		return extentreportname;
	}

	public String getCompanyName() {
		String compname = prop.getProperty("companyname");
		return compname;
	}

	public String getNoOfEmployees() {
		String noOfEmp = prop.getProperty("noofemp");
		return noOfEmp;
	}

	public String HBgetStartedbtn() {
		String contnbtn = prop.getProperty("HBgetstartedbtn");
		return contnbtn;
	}

	public String BCLinkCheck() {
		String bclink = prop.getProperty("backgrndchecktext");
		return bclink;
	}

	public String ComplincedbExternalLink() {
		String cmpliancedbextlinkyxt = prop.getProperty("CpmpliancedblinkText");
		return cmpliancedbextlinkyxt;
	}

	public String libHRproductWebcastLink() {
		String libHRproductWebcasttxt = prop
				.getProperty("HRProducrWecastPageText");
		return libHRproductWebcasttxt;
	}

	public String hbMaintainancePage() {
		String hbmaitncePage = prop.getProperty("HBMaintainancePage");
		return hbmaitncePage;
	}

	public String gethbStartPageurl() {
		String hbStartPageurl = prop.getProperty("HBStartPage");
		return hbStartPageurl;
	}

	public String getHBEmpAccessLoginUrl() {
		String hbEmpAccessloginurl = prop.getProperty("CreateHBLoginUrl");
		return hbEmpAccessloginurl;
	}

	public String getHBEmpAccessCompanyID() {
		String hbEmpAccessCid = prop.getProperty("CreateHBcompanyIdentifier");
		return hbEmpAccessCid;
	}

	public String getHBAccessPassword() {
		String hbEmpAccessPass = prop.getProperty("CreateHBPassword");
		return hbEmpAccessPass;
	}

	public String getMHOAccEmpContactName() {
		String empContactName = prop.getProperty("empContactName");
		return empContactName;
	}

	public String getMHOAccEmpContactTitle() {
		String empContactTitle = prop.getProperty("empContactTitle");
		return empContactTitle;
	}

	public String getMHOAccEmpContactPhone() {
		String empContactPhone = prop.getProperty("empContactPhone");
		return empContactPhone;
	}

	public String getMHOAccEmpContactAltPhone() {
		String empContactAltPhone = prop.getProperty("empContactAltPhone");
		return empContactAltPhone;
	}

	public String getMHOAccEmpContactEmail() {
		String empContactEmail = prop.getProperty("empContactEmail");
		return empContactEmail;
	}

	public String getMHOAccEmpContactphoneExt() {
		String empContactPhoneExt = prop.getProperty("empContactPhoneExt");
		return empContactPhoneExt;
	}

	public String getMHOAccEmpContactAltphoneExt() {
		String empContactAltPhoneExt = prop
				.getProperty("empContactAltPhoneExt");
		return empContactAltPhoneExt;
	}

	public String getLocalFilePath1() {
		String LocalFilePath1 = prop.getProperty("localFilePath1");
		return LocalFilePath1;
	}

	public String getLocalFilePath2() {
		String LocalFilePath2 = prop.getProperty("localFilePath2");
		return LocalFilePath2;
	}

	public String getLocalFilePath3() {
		String LocalFilePath3 = prop.getProperty("localFilePath3");
		return LocalFilePath3;
	}

	public String getTragethost() {
		String host = prop.getProperty("host");
		return host;
	}

	public String getTragethostuname() {
		String uname = prop.getProperty("hostUserName");
		return uname;
	}

	public String getTragethostpass() {
		String pass = prop.getProperty("hostPassword");
		return pass;
	}

	public int getTragethostPort() {
		prop.getProperty("port");
		return 0;

	}

	public String getTragethostDir() {
		String dir = prop.getProperty("hostdir");
		return dir;
	}

	public String getapiHost() {
		String apihost = prop.getProperty("Apihostname");
		return apihost;
	}

	public String getapiIID() {
		String apiiid = prop.getProperty("IID");
		return apiiid;

	}

	public String getapiOOID() {
		String apooid = prop.getProperty("ooid");
		return apooid;
	}

	public String getapiBundleID() {
		String bundleid = prop.getProperty("BundleID");
		return bundleid;
	}

	public String getProvisionAPIServiceURL() {
		String provisionURL = prop.getProperty("ProvisionServiceURL");
		return provisionURL;
	}

	public String getUpgradeAPIServiceURL() {
		String upgradeURL = prop.getProperty("UpgradeServiceURL");
		return upgradeURL;
	}

	public String getDowngradeAPIServiceURL() {
		String downgradeURL = prop.getProperty("DowngradeServiceURL");
		return downgradeURL;
	}

	public String getTrailStartAPIServiceURL() {
		String trailStartURL = prop.getProperty("TrialStartServiceURL");
		return trailStartURL;
	}

	public String getTrailEndAPIServiceURL() {
		String trailEndURL = prop.getProperty("TrialEndServiceURL");
		return trailEndURL;
	}

	public String getTerminationAPIServiceURL() {
		String terminationURL = prop.getProperty("TerminationServiceURL");
		return terminationURL;
	}

	public String getEssentialIID() {
		String essentialIID = prop.getProperty("testiidessential");
		return essentialIID;
	}
	
	public String getADPEnhancePayrollIID() {
		String essentialIID = prop.getProperty("testiidadpenhancedpayrollbundle");
		return essentialIID;
	}

	public String getEnhancedIID() {
		String enhancedIID = prop.getProperty("testiidenhanced");
		return enhancedIID;
	}

	public String getADPCompleteIID() {
		String completeIID = prop.getProperty("testiidadpcompletehrplus");
		return completeIID;
	}

	public String getstarterIID() {
		String starterIID = prop.getProperty("testiidhrstarter");
		return starterIID;
	}

	public String getAACAl() {
		String aaCal = prop.getProperty("AACalURI");
		return aaCal;
	}

	public String getPolicyAckCAl() {
		String policyAckCal = prop.getProperty("PolicyAckURI");
		return policyAckCal;
	}

	public String getPolicyAckStatusCAl() {
		String policyAckStatusCal = prop.getProperty("PolicyAckStatusURI");
		return policyAckStatusCal;
	}

	public String getPolicyDownloadCAl() {
		String policydnldCal = prop.getProperty("MyADPPDownloadCal");
		return policydnldCal;
	}
	
	public String getDocVaultAPIURI() {
		String docVault = prop.getProperty("docvaultapi");
		return docVault;
	}
}

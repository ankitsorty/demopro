package com.runhr411.utilities;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class Reporting extends TestListenerAdapter {

	ReadConfig readconfig = new ReadConfig();
	public ExtentHtmlReporter htmlreporter;
	public ExtentReports extent;
	public ExtentTest logger1;

	public void onStart(ITestContext testContext) {

		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String repName = "RUN-HR411-TestReport" + timeStamp + ".html";
		htmlreporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/Test Reports/" + repName);
		

		extent = new ExtentReports();
		extent.attachReporter(htmlreporter);
		extent.setSystemInfo("Host Name", readconfig.getHostName());
		extent.setSystemInfo("Environment", readconfig.getEnvironment());
		extent.setSystemInfo("User Name", readconfig.getUserName());

		htmlreporter.config().setDocumentTitle(readconfig.getExtentReportTiltle());
		htmlreporter.config().setReportName(readconfig.getExtentReportName());
		htmlreporter.config().setTheme(Theme.DARK);
	}

	public void onTestSuccess(ITestResult tcName) {

		logger1 = extent.createTest(tcName.getName());
		logger1.log(Status.PASS, MarkupHelper.createLabel(tcName.getName(), ExtentColor.GREEN));
	}

	public void onTestFailure(ITestResult tcName) {
		logger1 = extent.createTest(tcName.getName());
		logger1.log(Status.FAIL, MarkupHelper.createLabel(tcName.getName(), ExtentColor.RED));

		String screenshotPath = System.getProperty("user.dir") + "\\Screenshots\\" + tcName.getName() + ".png";
		File file = new File(screenshotPath);

		if (file.exists()) {

			try {
				logger1.fail("Screenshot is below : " + logger1.addScreenCaptureFromPath(screenshotPath));
			} catch (IOException e) {
				e.printStackTrace();
			}
			extent.flush();
		}

	}

	public void onTestSkipped(ITestResult tcName) {
		logger1 = extent.createTest(tcName.getName());// create new entry in report
		logger1.log(Status.SKIP, MarkupHelper.createLabel(tcName.getName(), ExtentColor.ORANGE));
		extent.flush();
	}

	public void onFinish(ITestContext testContext) {
		extent.flush();
	}
}
